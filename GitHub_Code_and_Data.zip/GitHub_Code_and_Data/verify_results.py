"""Verify frozen files and reproduce the primary and independent CPU analyses."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
KITCHEN = Path("information_vla/iteration2")
FOLLOWUP = Path("information_vla/iteration3")
COMMANDS = (
    (KITCHEN / "analyze_revision.py",),
    (KITCHEN / "audit_final.py",),
    (FOLLOWUP / "analyze.py", "timing", "transfer", "routes"),
    (FOLLOWUP / "review_timing.py",),
    (FOLLOWUP / "review_basket.py", "transfer", "--tags", "transfervla", "transfergeom",
     "--methods", "canonical", "late", "geometry", "mean"),
    (FOLLOWUP / "review_basket.py", "routes", "--tags", "routecontrols", "routeoutput",
     "routeinside", "routeswap", "--methods", "geometry", "bc", "late", "inside", "swapped"),
)
OUTPUTS = [KITCHEN / name for name in ("results.json", "method_summary.csv",
           "layout_outcomes.csv", "trial_outcomes.csv", "review_recalculation.json")]
OUTPUTS.extend(FOLLOWUP / name for group in ("timing", "transfer", "routes")
               for name in (f"{group}_results.json", f"{group}_trials.csv",
                            f"review_{group}_results.json"))


def check_manifest():
    files = []
    for line in (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        path = ROOT / name
        if not path.resolve().is_relative_to(ROOT) or not path.is_file():
            raise ValueError(f"Missing or unsafe manifest entry: {name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"SHA-256 mismatch: {name}")
        files.append(Path(name))
    if len(files) != len(set(files)):
        raise ValueError("Duplicate manifest entries")
    print(f"Verified {len(files)} SHA-256 entries.", flush=True)
    return files


def compare(left, right, location):
    if isinstance(left, dict) and isinstance(right, dict) and left.keys() == right.keys():
        for key in left:
            compare(left[key], right[key], f"{location}.{key}")
    elif isinstance(left, list) and isinstance(right, list) and len(left) == len(right):
        for index, (a, b) in enumerate(zip(left, right)):
            compare(a, b, f"{location}[{index}]")
    elif isinstance(left, float) and isinstance(right, float):
        if not math.isclose(left, right, rel_tol=1e-11, abs_tol=1e-12):
            raise ValueError(f"Numeric mismatch at {location}: {left} vs {right}")
    elif type(left) is not type(right) or left != right:
        raise ValueError(f"Mismatch at {location}: {left!r} vs {right!r}")


def load_result(path):
    if path.suffix == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.reader(stream))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hashes-only", action="store_true")
    args = parser.parse_args()
    files = check_manifest()
    if args.hashes_only:
        return
    with TemporaryDirectory(prefix="vla-audit-") as directory:
        working = Path(directory)
        for relative in files:
            if relative.parts[0] != "information_vla" or relative in OUTPUTS:
                continue
            target = working / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, target)
        for script, *arguments in COMMANDS:
            subprocess.run([sys.executable, str(script), *arguments], cwd=working, check=True)
        for relative in OUTPUTS:
            compare(load_result(ROOT / relative), load_result(working / relative), str(relative))
    a, b = json.loads((ROOT / KITCHEN / "results.json").read_text(encoding="utf-8"))["rollouts"], [
        json.loads((ROOT / FOLLOWUP / f"{group}_results.json").read_text(encoding="utf-8"))["executed"]
        for group in ("timing", "transfer", "routes")]
    print(f"Recreated {len(OUTPUTS)} result files covering {a + sum(b)} recorded episodes.")


if __name__ == "__main__":
    main()
