"""Generate audited continuation trajectories under a geometric teacher in the native scene."""
import argparse
import time
from native import *


class Endpoint:
    def __init__(self):
        self.streak = np.zeros((2, 2), int)

    def step(self, env):
        for o, obj in enumerate(OBJECTS):
            for d, dest in enumerate(DESTINATIONS):
                self.streak[o,d] = self.streak[o,d]+1 if landed(env,obj,dest) else 0
                if self.streak[o,d] >= 3:
                    return o,d
        return None


def move(error, grip, gain=18):
    return np.r_[np.clip(gain*error,-.75,.75),0.,0.,0.,grip].astype("f")


class GeometricTeacher:
    def __init__(self, env, obs, home, orig, arm, pickup=None):
        self.env, self.home = env, home
        self.o, self.d = target(orig,arm)
        self.first = bool(self.o)
        self.obj = BOWL
        self.phase = 0
        self.free = 0
        self.cheese_z = position(env,obs,CHEESE)[2]
        self.begin(obs)
        self.close_steps = 0
        self.acquire = 0

    def begin(self, obs):
        pos = position(self.env,obs,self.obj)
        if self.first:
            dest = self.home.copy()
        else:
            center = site(self.env,obs,self.d)
            dest = np.r_[center[:2], (self.home[2] if self.obj == BOWL else self.cheese_z) +
                         (.008 if self.d == 0 else .031)]
        high = max(dest[2],pos[2]) + .09
        self.points = [np.r_[pos[:2],high],np.r_[dest[:2],high],dest+[0,0,.012]]
        self.phase = 0

    def act(self, obs):
        if self.phase == 4:
            cp = position(self.env,obs,CHEESE)
            if grabbed(self.env,CHEESE) and cp[2] > self.cheese_z+.016:
                self.obj, self.first = CHEESE, False
                self.begin(obs)
            else:
                pads = self.env.env.robots[0].gripper.important_geoms
                mid = np.mean([self.env.sim.data.get_geom_xpos(pads[k][0]) for k in
                               ("left_fingerpad","right_fingerpad")],axis=0)
                waypoint = cp.copy()
                if self.acquire == 0:
                    waypoint = np.r_[self.lift_xy, self.cheese_z+.10]
                elif self.acquire == 1:
                    waypoint[2] = self.cheese_z+.10
                elif self.acquire in (2,3):
                    waypoint[2] = self.cheese_z+.007
                else:
                    waypoint[2] = self.cheese_z+.09
                error = waypoint-mid
                grip = 1 if self.acquire >= 3 else -1
                if self.acquire < 3 and np.linalg.norm(error)<.012:
                    self.acquire += 1
                elif self.acquire == 3:
                    self.close_steps += 1
                    if self.close_steps >= 9:
                        self.acquire = 4
                return move(error,grip,22)
        if self.phase < 3:
            pos = position(self.env,obs,self.obj)
            error = self.points[self.phase] - pos
            if np.linalg.norm(error) < .014:
                self.phase += 1
            if self.phase < 3:
                return move(self.points[self.phase]-pos,1)
        if self.first:
            self.free += 1
            if self.free >= 7:
                self.phase = 4
                self.lift_xy = obs["robot0_eef_pos"][:2].copy()
        return move(np.zeros(3),-1)


def collect(seeds, budget, arms=ARMS, folder="demos_v2"):
    out = HERE / folder
    out.mkdir(exist_ok=True)
    log = out / "trials.jsonl"
    done = {(r["seed"],r["orig"],r["stage"],r["arm"]) for r in
            map(json.loads,log.read_text().splitlines())} if log.exists() else set()
    torch.set_num_threads(2)
    env = make_env()
    try:
        for seed in seeds:
            for orig in (0,1):
                for stage in ("grasp","near"):
                    path = snap_path(seed,orig,stage)
                    if not path.exists():
                        continue
                    for arm in arms:
                        if (seed,orig,stage,arm) in done:
                            continue
                        obs, home = restore(env,path)
                        reseed(9033+seed)
                        teacher = GeometricTeacher(env,obs,home,orig,arm)
                        monitor = Endpoint()
                        images, wrists, proprio, actions = [],[],[],[]
                        for t in range(budget):
                            if t%10 == 0:
                                im,wr,p = encode_obs(obs)
                                images.append(im); wrists.append(wr); proprio.append(p)
                            a = teacher.act(obs)
                            actions.append(a)
                            obs = step_visual(env,a,(t+1)%10==0)
                            end = monitor.step(env)
                            if end is not None:
                                break
                        success = end == target(orig,arm)
                        key = f"{seed}_{orig}_{stage}_{arm}"
                        if success:
                            np.savez_compressed(out / (key+".npz"), image=images,wrist=wrists,proprio=proprio,
                                                actions=actions)
                        row = dict(seed=seed,orig=orig,stage=stage,arm=arm,success=success,
                                   end=end,steps=t+1,teacher_phase=teacher.phase,file=key if success else None)
                        jsonline(log,row)
                        print(row,flush=True)
    finally:
        env.close()


if __name__ == "__main__":
    arg=argparse.ArgumentParser()
    arg.add_argument("seeds",type=int,nargs="+")
    arg.add_argument("--budget",type=int,default=180)
    arg.add_argument("--arms",nargs="+",choices=ARMS,default=ARMS)
    arg.add_argument("--folder",default="demos_v2")
    args=arg.parse_args()
    collect(args.seeds,args.budget,args.arms,args.folder)
