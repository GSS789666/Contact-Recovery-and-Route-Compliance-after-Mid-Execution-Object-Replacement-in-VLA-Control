"""Independently replay nine saved trajectories and rescore first delivery in LIBERO."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

from native import LIB, OBJECTS, SCENE, TARGETS, reset_to_start
from libero.libero.envs.env_wrapper import ControlEnv


ROOT = Path(__file__).resolve().parent
TAGS = ("frozen", "canonical33", "teacher")
ARMS = ("confirm", "destination", "object")


def rescore(env, trace):
    """Inspect all four object--site pairs after every action, independently of Endpoint."""
    streak = np.zeros((2, 2), dtype=int)
    largest_error = 0.0
    for step, sample in enumerate(trace, 1):
        obs = env.step(sample[:7])[0]
        sample_positions = [obs["robot0_eef_pos"]]
        for obj_index, obj in enumerate(OBJECTS):
            body_id = env.env.obj_body_id[obj]
            sample_positions.append(env.sim.data.body_xpos[body_id])
            held = env.env._check_grasp(env.env.robots[0].gripper, env.env.get_object(obj))
            for site_index, site in enumerate(("plate", "stove")):
                on_site = env.env._eval_predicate(["on", obj, TARGETS[site]])
                if on_site and not held:
                    streak[obj_index, site_index] += 1
                else:
                    streak[obj_index, site_index] = 0
        error = float(np.max(np.abs(np.concatenate(sample_positions) - sample[7:])))
        largest_error = max(largest_error, error)
        candidates = np.argwhere(streak >= 3)
        if len(candidates):
            return candidates[0].tolist(), step, largest_error
    return None, len(trace), largest_error


def endpoint_text(end):
    return "timeout" if end is None else f"{end[0]}-{end[1]}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "measured_replay.csv")
    args = parser.parse_args()
    scene = LIB / "bddl_files/libero_goal" / f"{SCENE}.bddl"
    env = ControlEnv(bddl_file_name=str(scene), use_camera_obs=False,
                     has_offscreen_renderer=False, hard_reset=True, ignore_done=True)
    measured = []
    try:
        for tag in TAGS:
            log = ROOT / "evaluation" / f"{tag}.jsonl"
            rows = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
            for arm in ARMS:
                candidates = [r for r in rows if r["stage"] == "near" and r["arm"] == arm]
                row = min(candidates, key=lambda r: (r["seed"], r["orig"]))
                snapshot = ROOT / "snapshots" / f'{row["seed"]}_{row["orig"]}_near.npz'
                with np.load(snapshot) as snap:
                    if str(snap["signature"]) != row["snapshot"]:
                        raise ValueError(f"Snapshot identity differs for {tag}, {arm}")
                    reset_to_start(env, snap["initial"], row["seed"])
                    for action in snap["actions"]:
                        env.step(action)
                with np.load(ROOT / "evaluation" / row["trace"]) as saved:
                    trace = saved["trace"]
                if trace.shape != (row["steps"], 16) or not np.isfinite(trace).all():
                    raise ValueError(f"Invalid trajectory for {tag}, {arm}")
                end, step, error = rescore(env, trace)
                matched = end == row["end"] and step == row["steps"]
                if end is None and step != 180:
                    raise ValueError(f"Premature timeout for {tag}, {arm}")
                measured.append({
                    "run": tag, "layout": row["seed"], "original_destination": row["orig"],
                    "stage": row["stage"], "edit": arm, "source_trace": row["trace"],
                    "snapshot_sha256": row["snapshot"], "logged_endpoint": endpoint_text(row["end"]),
                    "replayed_endpoint": endpoint_text(end), "logged_steps": row["steps"],
                    "replayed_steps": step, "max_abs_coordinate_error_m": error,
                    "matched_first_delivery_and_step": int(matched),
                })
    finally:
        env.close()
    with args.output.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(measured[0]))
        writer.writeheader()
        writer.writerows(measured)
    if not all(row["matched_first_delivery_and_step"] for row in measured):
        raise SystemExit("At least one replay has a different first delivery or step count.")
    print(f"{len(measured)} trajectories matched. Report: {args.output.name}")


if __name__ == "__main__":
    main()
