"""Draw the inference path for the structured correction-conditioned flow residual."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

out = Path(__file__).resolve().parent / "paper"
fig, ax = plt.subplots(figsize=(9.5,3.15))
fig.subplots_adjust(0.012,0.025,0.99,0.96)
ax.set(xlim=(0,12),ylim=(0,4))
ax.axis("off")
ink="#203846"
blue="#e8f1f7"
sage="#e3f0e9"
gray="#f1f3f4"


def box(x,y,w,h,title,text,fill):
    rect=FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.04,rounding_size=0.12",
                        edgecolor=ink,facecolor=fill,linewidth=1.1)
    ax.add_patch(rect)
    ax.text(x+w/2,y+h*.67,title,ha="center",va="center",fontsize=10.5,weight="bold",color=ink)
    ax.text(x+w/2,y+h*.29,text,ha="center",va="center",fontsize=9.4,color=ink)


def arrow(points):
    xs,ys=zip(*points[:-1])
    if len(xs)>1:
        ax.plot(xs,ys,color=ink,lw=1.3)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle="-|>",
                                 mutation_scale=12,color=ink,lw=1.3,shrinkA=0,shrinkB=0))


box(.12,2.57,2.77,1,"Policy inputs","RGB views, arm state, old goal",gray)
box(3.51,2.57,2.20,1,"Frozen SmolVLA","Action-flow expert",blue)
box(.12,.54,2.77,1,"Language inputs","Old goal and short correction",gray)
box(3.51,.54,2.20,1,"Role encoding","Edit gates and roles",sage)
box(6.48,.54,2.47,1,"Trainable residual","Expert features, roles, state",sage)
box(9.7,2.57,2.15,1,"Action flow","Base velocity + residual",blue)
arrow([(2.94,3.07),(3.44,3.07)])
arrow([(2.94,1.04),(3.44,1.04)])
arrow([(5.76,1.04),(6.40,1.04)])
arrow([(5.76,3.07),(9.61,3.07)])
ax.text(7.50,3.27,"base velocity",ha="center",fontsize=9,color=ink)
arrow([(4.63,2.52),(4.63,2.07),(7.72,2.07),(7.72,1.62)])
ax.text(6.85,2.24,"expert features",ha="center",fontsize=9,color=ink)
arrow([(9.01,1.04),(10.77,1.04),(10.77,2.50)])
ax.text(9.91,1.64,"7 channels",fontsize=8.8,color=ink,ha="center")
out.mkdir(exist_ok=True)
fig.savefig(out/"model_path.pdf",bbox_inches="tight",pad_inches=.045)
plt.close(fig)
