"""Render the first audited near-site object correction from recorded controls."""
import csv

import av
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from demonstrations import Endpoint
from native import HERE, encode_obs, make_env, restore, snap_path, step_visual

TITLES = {"frozen": "Frozen + full goal", "canonical33": "Full goal + residual", "teacher": "Geometric teacher"}
OUTCOMES = {"0-0": "Bowl delivered to plate", "1-0": "Cheese delivered to plate", "timeout": "Time limit reached"}
FONT = ImageFont.load_default(size=16)
SMALL = ImageFont.load_default(size=14)


def collect(env, row):
    layout, old = int(row["layout"]), int(row["original_destination"])
    obs, _ = restore(env, snap_path(layout, old, row["stage"]))
    frames = {0: Image.fromarray(encode_obs(obs)[0])}
    score = Endpoint()
    with np.load(HERE/"evaluation"/row["source_trace"]) as bank:
        actions = bank["trace"][:, :7]
    for step, action in enumerate(actions, 1):
        capture = step % 2 == 0 or step == len(actions)
        obs = step_visual(env, action, capture)
        end = score.step(env)
        if capture:
            frames[step] = Image.fromarray(encode_obs(obs)[0])
        if end is not None:
            assert step == len(actions)
    code = "timeout" if end is None else f"{end[0]}-{end[1]}"
    assert code == row["replayed_endpoint"]
    return frames, len(actions)


def main():
    with (HERE/"measured_replay.csv").open(newline="") as stream:
        rows = [row for row in csv.DictReader(stream) if row["edit"] == "object"]
    assert len(rows)==3 and len({row["snapshot_sha256"] for row in rows})==1
    env = make_env()
    try:
        panels = [collect(env, row) for row in rows]
    finally:
        env.close()
    with av.open(str(HERE/"paper/heldout_replay.mp4"), mode="w") as video:
        stream = video.add_stream("libx264",rate=10)
        stream.width,stream.height,stream.pix_fmt=800,372,"yuv420p"
        stream.options={"crf":"19"}
        for t in range(0,181,2):
            sheet=Image.new("RGB",(800,372),"#fbfcfd")
            draw=ImageDraw.Draw(sheet)
            draw.text((10,6),"Object correction during transport",fill="#1c3545",font=FONT)
            draw.text((10,28),"Old goal: bowl to plate.   Correction: use the cream cheese instead.",fill="#1c3545",font=SMALL)
            draw.text((622,8),f"Control step {t:3d} / 180",fill="#1c3545",font=SMALL)
            for i,(row,(frames,length)) in enumerate(zip(rows,panels)):
                x=9+i*263
                draw.text((x,57),TITLES[row["run"]],fill="#1c3545",font=FONT)
                sheet.paste(frames[min(t,length)],(x,80))
                status="Executing" if t<length else f"{OUTCOMES[row['replayed_endpoint']]} ({length})"
                draw.text((x,343),status,fill="#1c3545",font=SMALL)
            frame=av.VideoFrame.from_image(sheet)
            for pack in stream.encode(frame):
                video.mux(pack)
        for pack in stream.encode():
            video.mux(pack)


if __name__=="__main__":
    main()
