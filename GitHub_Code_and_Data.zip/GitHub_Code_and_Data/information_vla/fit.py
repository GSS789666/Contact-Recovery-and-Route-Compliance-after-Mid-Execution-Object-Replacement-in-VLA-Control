"""Extract frozen expert features for flow matching and fit matched residual heads."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from native import ARMS, HERE, Policy, sentences, target
from adapter import FlowAdapter, lex, observation_batch

DEMO=HERE/"demos_v2"
CACHE=HERE/"flow_features_v1"
MODES=("ordinary","perfect","role","paired")


def cache(files,canonical=False):
    CACHE.mkdir(exist_ok=True)
    keys={f:hashlib.sha256(f.read_bytes()).hexdigest()+":a24f1f380461b665158d52acd140152c79e8b36d:flow4-v1:"+str(canonical) for f in files}
    def current(f):
        if not (CACHE/f.name).exists(): return False
        with np.load(CACHE/f.name) as d:
            return "source_key" in d and str(d["source_key"])==keys[f]
    pending=[f for f in files if not current(f)]
    if not pending:
        return
    pol=Policy(10)
    model=pol.model
    captured=[]
    def capture(module,ins,outs):
        captured.extend([ins[0].detach(),outs.detach()])
    hook=model.model.action_out_proj.register_forward_hook(capture)
    with torch.inference_mode():
        for f in pending:
            seed,orig,stage,arm=f.stem.split("_")
            seed,orig=int(seed),int(orig)
            old,c,full=sentences(orig,arm)
            with np.load(f) as data:
                acts=torch.as_tensor(data["actions"],device="cuda",dtype=torch.float32)
                acts=(acts-pol.stats["action.mean"].cuda())/(pol.stats["action.std"].cuda()+1e-8)
                im,wr,p=data["image"],data["wrist"],data["proprio"]
            H,R,P,M,T=[],[],[],[],[]
            torch.manual_seed(4431+seed*73+orig*19+(stage=="near")*7+ARMS.index(arm))
            for ix in range(0,len(im),3):
                starts=np.arange(ix,min(ix+3,len(im)))
                prompt=full if canonical else old
                batch=observation_batch(pol,im[starts],wr[starts],p[starts],[prompt]*len(starts))
                images,mask=model.prepare_images(batch)
                state=model.prepare_state(batch)
                time_ix=torch.as_tensor(starts[:,None]*10+np.arange(50)[None,:],device="cuda")
                valid=time_ix<len(acts)
                a=acts[time_ix.clamp(max=len(acts)-1)]
                a=F.pad(a,(0,model.config.max_action_dim-7))
                for _ in range(4):
                    noise=torch.randn_like(a)
                    time=model.model.sample_time(len(starts),"cuda")
                    captured.clear()
                    model.model.forward(images,mask,batch["observation.language.tokens"],
                        batch["observation.language.attention_mask"],state,a,noise,time)
                    h,v0=captured
                    H.append(h.cpu().half().numpy())
                    R.append((noise[:,:,:7]-a[:,:,:7]-v0[:,:,:7]).cpu().half().numpy())
                    P.append(batch["observation.state"].cpu().numpy())
                    M.append(valid.cpu().numpy())
                    T.append(starts)
            output=CACHE/f.name
            tmp=output.with_suffix(".tmp.npz")
            np.savez(tmp,h=np.concatenate(H),r=np.concatenate(R),p=np.concatenate(P),
                     mask=np.concatenate(M),index=np.concatenate(T),length=len(acts),source_key=keys[f])
            tmp.replace(output)
            print("cached",f.stem,flush=True)
    hook.remove()


def dataset(files):
    items={k:[] for k in ("h","r","p","mask","x","gt","pair","alt")}
    for f in files:
        _,orig,_,arm=f.stem.split("_")
        orig=int(orig)
        old,c,_=sentences(orig,arm)
        with np.load(CACHE/f.name) as d:
            n=len(d["h"])
            for k in ("h","r","p","mask"):
                items[k].append(d[k])
            items["x"].append(np.tile(lex(old,c),(n,1)))
            items["gt"].append(np.tile([arm=="object",arm=="destination"],(n,1)))
            items["pair"].append((d["index"]==0)&(int(d["length"])<=50))
            alternatives=[lex(old,sentences(orig,b)[1]) for b in ARMS if b!=arm]
            items["alt"].append(np.tile(alternatives,(n,1,1)))
    return {k:torch.from_numpy(np.concatenate(v)).cuda() for k,v in items.items()}


def score(model,dat,index,with_pair=True):
    x=dat["x"][index].float()
    h=dat["h"][index].float()
    p=dat["p"][index].float()
    y=dat["r"][index].float()
    m=dat["mask"][index]
    pred,gate=model(h,x,p)
    def err(output):
        return ((output-y).square().mean(2)*m).sum(1)/m.sum(1)
    err0=err(pred)
    loss=err0.mean()
    if model.mode in ("role","paired"):
        loss=loss+.15*F.binary_cross_entropy(gate,dat["gt"][index].float())
    eligible=dat["pair"][index]
    if model.mode=="paired" and with_pair and eligible.any():
        terms=[]
        for j in range(2):
            bad,_=model(h,dat["alt"][index,j].float(),p)
            terms.append(F.relu(.1+err0-err(bad))[eligible].mean())
        loss=loss+.2*torch.stack(terms).mean()
    return loss,err0.detach()


def fit(seed,tr,dev,width,epochs,modes=MODES):
    out=HERE/"weights"
    out.mkdir(exist_ok=True)
    for mode in modes:
        torch.manual_seed(seed)
        model=FlowAdapter(width,mode).cuda()
        opt=torch.optim.AdamW(model.parameters(),lr=.001)
        best=float("inf")
        rng=torch.Generator(device="cpu").manual_seed(seed)
        history=[]
        for ep in range(epochs):
            model.train()
            for ix in torch.randperm(len(tr["x"]),generator=rng).split(64):
                loss,_=score(model,tr,ix.cuda())
                opt.zero_grad();loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),2.)
                opt.step()
            model.eval()
            with torch.no_grad():
                errs=[score(model,dev,ix.cuda(),False)[1] for ix in torch.arange(len(dev["x"])).split(64)]
            val=torch.cat(errs).mean().item()
            history.append(val)
            if val < best:
                best=val
                snapshot={k:v.detach().cpu() for k,v in model.state_dict().items()}
                torch.save(dict(width=width,mode=mode,state=snapshot,
                                epoch=ep+1,val=val),out/f"{seed}_{mode}.pt")
        (out/f"{seed}_{mode}.json").write_text(json.dumps(history))
        print("fit",seed,mode,best,flush=True)


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--cache-only",action="store_true")
    ap.add_argument("--canonical",action="store_true")
    ap.add_argument("--seeds",type=int,nargs="+",default=[33,34,35])
    ap.add_argument("--epochs",type=int,default=50)
    args=ap.parse_args()
    if args.canonical:
        CACHE=HERE/"flow_features_canonical"
    torch.set_num_threads(2)
    files=sorted(f for f in DEMO.glob("*.npz") if not f.stem.endswith("_object"))
    files+=sorted((HERE/"demos_regrasp").glob("*_object.npz"))
    files=[f for f in files if int(f.stem.split("_")[0])<8]
    cache(files,args.canonical)
    if not args.cache_only:
        train=[f for f in files if int(f.stem.split("_")[0])<6]
        val=[f for f in files if int(f.stem.split("_")[0])>=6]
        tr,dev=dataset(train),dataset(val)
        for seed in args.seeds:
            fit(seed,tr,dev,tr["h"].shape[-1],args.epochs,("canonical",) if args.canonical else MODES)
