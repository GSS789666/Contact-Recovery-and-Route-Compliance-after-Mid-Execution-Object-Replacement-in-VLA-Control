$ErrorActionPreference = 'Stop'
$pythonExe = Join-Path $env:LOCALAPPDATA 'vla-pilot/venv/Scripts/python.exe'
$studyPath = $PSScriptRoot
$pending = @(
    @{seed=33; modes=@('ordinary','perfect','role','paired'); tag='learned33'; marker='33_paired.json'},
    @{seed=34; modes=@('ordinary','perfect','role','paired'); tag='learned34'; marker='34_paired.json'},
    @{seed=35; modes=@('ordinary','perfect','role','paired'); tag='learned35'; marker='35_paired.json'},
    @{seed=33; modes=@('canonical'); tag='canonical33'; marker='33_canonical.json'}
)
$running = @()
while ($pending.Count -or $running.Count) {
    foreach ($proc in @($running)) {
        if ($proc.HasExited) {
            if ($proc.ExitCode -ne 0) { throw "Evaluation worker failed, PID $($proc.Id)" }
            $running = @($running | Where-Object Id -ne $proc.Id)
        }
    }
    foreach ($entry in @($pending)) {
        if ($running.Count -ge 2) { break }
        if (-not (Test-Path (Join-Path $studyPath ('weights/' + $entry.marker)))) { continue }
        $arguments = @('-u',('"' + (Join-Path $studyPath 'evaluate.py') + '"'),'--methods') + $entry.modes + @('--fit-seed',$entry.seed,'--tag',$entry.tag)
        $proc = Start-Process -FilePath $pythonExe -ArgumentList $arguments -WorkingDirectory $studyPath -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $studyPath ($entry.tag+'.log')) -RedirectStandardError (Join-Path $studyPath ($entry.tag+'.stderr.log'))
        $running += $proc
        $pending = @($pending | Where-Object tag -ne $entry.tag)
    }
    if ($pending.Count -or $running.Count) { Start-Sleep -Seconds 4 }
}
