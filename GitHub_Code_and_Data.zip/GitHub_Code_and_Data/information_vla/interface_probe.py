"""A constructive input-collision test for the finite phrase interface."""
import csv
from native import HERE, ARMS, DESTINATIONS, sentences
from adapter import lex
rows=[]
for orig,d in enumerate(DESTINATIONS):
    paraphrases=("yes, proceed as before",
                 ("use the stovetop burner instead" if orig==0 else "use the red-rimmed dish instead"),
                 "switch to the blue dairy package")
    group=[]
    for arm,alternate in zip(ARMS,paraphrases):
        old,canonical,_=sentences(orig,arm)
        for kind,c in (("study grammar",canonical),("constructed paraphrase",alternate)):
            code=tuple(map(int,lex(old,c)))
            rows.append(dict(original=d,edit=arm,version=kind,text=c,code="".join(map(str,code))))
            if kind=="constructed paraphrase":group.append(code)
    assert len(set(group))==1
with (HERE/"interface_probe.csv").open("w",newline="",encoding="utf-8-sig") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
