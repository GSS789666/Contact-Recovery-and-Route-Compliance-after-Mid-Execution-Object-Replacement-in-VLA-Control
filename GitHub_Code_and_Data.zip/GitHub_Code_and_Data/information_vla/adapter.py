"""Matched action-flow residuals. The canonical control restates the effective goal to the backbone."""
import numpy as np
import torch
from torch import nn
from native import OBJECTS, encode_obs, sentences

def lex(old, correction):
    phrases = ("cream cheese","on the plate","on the stove","keep going")
    return [float(s in correction) for s in phrases] + [float(s in old) for s in ("plate","stove")]


def observation_batch(policy, front, wrist, state, texts):
    batch={}
    for i, arr in enumerate((front,wrist),1):
        batch[f"observation.images.camera{i}"] = torch.as_tensor(arr,device="cuda").permute(0,3,1,2).float()/255.
    p = torch.as_tensor(state,device="cuda",dtype=torch.float32)
    batch["observation.state"] = (p-policy.stats["observation.state.mean"].cuda())/(policy.stats["observation.state.std"].cuda()+1e-8)
    tokens = policy.tokenizer([t+"\n" for t in texts],max_length=48,padding="max_length",truncation=True,return_tensors="pt")
    batch["observation.language.tokens"]=tokens.input_ids.cuda()
    batch["observation.language.attention_mask"]=tokens.attention_mask.bool().cuda()
    return batch


class FlowAdapter(nn.Module):
    def __init__(self, width, mode):
        super().__init__()
        self.mode=mode
        self.gate=nn.Linear(6,2)
        self.hidden=nn.Sequential(nn.LayerNorm(width,elementwise_affine=False),nn.Linear(width,64))
        self.condition=nn.Linear(16,64)
        self.out=nn.Linear(64,7)
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self,h,x,p):
        gates=self.gate(x).sigmoid()
        old_dest=x[:,4:6]
        edited_dest=x[:,1:3]
        fallback=torch.where(edited_dest.sum(1,keepdim=True)>0,edited_dest,old_dest)
        if self.mode in ("ordinary","perfect","canonical"):
            if self.mode == "ordinary":
                roles=x
            else:
                o=x[:,:1]
                roles=torch.cat([1-o,o,fallback,o,x[:,1:3].sum(1,keepdim=True)],dim=1)
        else:
            obj=gates[:,:1]*x[:,:1]
            dest=old_dest*(1-gates[:,1:])+fallback*gates[:,1:]
            roles=torch.cat([1-obj,obj,dest,gates],1)
        cond=torch.cat([roles,gates,p],1)
        delta=self.out(torch.nn.functional.silu(self.hidden(h)+self.condition(cond)[:,None,:]))
        return delta,gates

class LearnedControl:
    def __init__(self,policy):
        self.policy=policy
        self.adapter=None
        self.context=None
        self.queue=[]
        self.hook = policy.model.model.action_out_proj.register_forward_hook(self.modify)

    def modify(self,module,inputs,output):
        if self.adapter is None:
            return output
        x,p=self.context
        delta,_=self.adapter(inputs[0].float(),x,p)
        return torch.cat([output[:,:,:7]+delta,output[:,:,7:]],-1)

    def reset(self,adapter,original,arm):
        self.policy.reset()
        self.queue=[]
        self.adapter=adapter
        self.old,self.correction,self.full=sentences(original,arm)

    @torch.inference_mode()
    def act(self,obs):
        if self.adapter is None:
            return self.policy.act(obs,self.full)
        if not self.queue:
            im,wr,p=encode_obs(obs)
            prompt=self.full if self.adapter.mode=="canonical" else self.old
            batch=observation_batch(self.policy,im[None],wr[None],p[None],[prompt])
            self.context=(torch.tensor([lex(self.old,self.correction)],device="cuda"),batch["observation.state"])
            a=self.policy.model.predict_action_chunk(batch)[0,:10,:7].float().cpu()
            a=a*self.policy.stats["action.std"]+self.policy.stats["action.mean"]
            self.queue=list(a.numpy())
        return self.queue.pop(0)
