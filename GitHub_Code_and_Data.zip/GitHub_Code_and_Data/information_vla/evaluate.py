"""Paired closed-loop evaluation; one immutable row per controller and branch."""
import argparse
import hashlib
import itertools
import random
import time
from demonstrations import Endpoint, GeometricTeacher
from adapter import FlowAdapter, LearnedControl
from native import *


def evaluate(args):
    torch.set_num_threads(2)
    out=HERE/"evaluation"
    out.mkdir(exist_ok=True)
    log=out/(args.tag+".jsonl")
    trials=[(s,o,stage,arm,method) for s,o,stage,arm,method in
            itertools.product(args.layouts,(0,1),args.stages,ARMS,args.methods)
            if snap_path(s,o,stage).exists()]
    random.Random(4801).shuffle(trials)
    seen={tuple(r[k] for k in ("seed","orig","stage","arm","method")) for r in
          map(json.loads,log.read_text().splitlines())} if log.exists() else set()
    controllers={}
    hashes={}
    if any(m!="teacher" for m in args.methods):
        policy=Policy(10)
        driver=LearnedControl(policy)
    for mode in set(args.methods)-{"frozen","teacher"}:
        weight_path=HERE/"weights"/f"{args.fit_seed}_{mode}.pt"
        hashes[mode]=hashlib.sha256(weight_path.read_bytes()).hexdigest()
        weights=torch.load(weight_path,weights_only=True)
        model=FlowAdapter(weights["width"],mode).cuda().eval()
        model.load_state_dict(weights["state"])
        controllers[mode]=model
    if log.exists():
        for row in map(json.loads,log.read_text().splitlines()):
            if row["method"] in controllers and (row["fit_seed"]!=args.fit_seed or
                      row.get("weight_sha256")!=hashes[row["method"]]):
                raise ValueError("Existing run uses different trained weights")
    env=make_env()
    try:
        for key in trials:
            if key in seen: continue
            seed,orig,stage,arm,mode=key
            path=snap_path(seed,orig,stage)
            obs,home=restore(env,path)
            signature=digest(env,obs)
            reseed(3033+seed)
            if mode=="teacher":
                ctrl=GeometricTeacher(env,obs,home,orig,arm)
            else:
                ctrl=driver
                ctrl.reset(controllers.get(mode),orig,arm)
            terminal=Endpoint()
            traj=[]
            for t in range(180):
                action=ctrl.act(obs)
                obs=step_visual(env,action,(t+1)%10==0 and mode!="teacher")
                end=terminal.step(env)
                traj.append(np.r_[action,obs["robot0_eef_pos"],position(env,obs,BOWL),position(env,obs,CHEESE)])
                if end is not None: break
            keystr=f"{args.tag}_{seed}_{orig}_{stage}_{arm}_{mode}"
            np.savez_compressed(out/(keystr+".npz"),trace=traj)
            row=dict(zip(("seed","orig","stage","arm","method"),key))
            row.update(end=end,success=end==target(orig,arm),steps=t+1,snapshot=signature,
                       fit_seed=args.fit_seed if mode in controllers else None,
                       weight_sha256=hashes.get(mode),trace=keystr+".npz")
            jsonline(log,row)
            print("finished",len(seen)+1,"/",len(trials),flush=True)
            seen.add(key)
    finally:
        env.close()

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--layouts",type=int,nargs="+",default=list(range(8,14)))
    p.add_argument("--fit-seed",type=int,default=33)
    p.add_argument("--methods",nargs="+",required=True)
    p.add_argument("--stages",nargs="+",default=["grasp","near"])
    p.add_argument("--tag",required=True)
    args=p.parse_args()
    import msvcrt
    lockdir=HERE/"evaluation"
    lockdir.mkdir(exist_ok=True)
    with (lockdir/(args.tag+".lock")).open("a+b") as lock:
        if lock.tell()==0: lock.write(b"0"); lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:
            print("An evaluation worker already owns this run.",flush=True)
        else:
            try: evaluate(args)
            finally:
                lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
