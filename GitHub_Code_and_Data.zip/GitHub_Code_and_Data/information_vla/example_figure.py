"""Render three verified training-layout demonstrator continuations at observed steps."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from native import *
from demonstrations import Endpoint
env=make_env()
fig,axes=plt.subplots(3,3,figsize=(8,7),layout="constrained")
for row,(arm,title) in enumerate(zip(ARMS,("Confirm\nbowl to plate","Change site\nbowl to stove","Change item\ncheese to plate"))):
    folder="demos_regrasp" if arm=="object" else "demos_v2"
    with np.load(HERE/f"{folder}/0_0_grasp_{arm}.npz") as demo:
        actions=demo["actions"]
    obs,_=restore(env,snap_path(0,0,"grasp"))
    mid=len(actions)//2
    frames=[encode_obs(obs)[0]]
    score=Endpoint()
    for i,a in enumerate(actions,1):
        obs=step_visual(env,a,i in (mid,len(actions)))
        if i in (mid,len(actions)): frames.append(encode_obs(obs)[0])
        end=score.step(env)
    assert end==target(0,arm)
    for j,(frame,t) in enumerate(zip(frames,(0,mid,len(actions)))):
        ax=axes[row,j]
        ax.imshow(frame);ax.set_xticks([]);ax.set_yticks([])
        ax.set_xlabel(f"step {t}",fontsize=9)
        for spine in ax.spines.values():spine.set_visible(False)
    axes[row,0].set_ylabel(title,fontsize=9)
for ax,t in zip(axes[0],("Intervention","Midpoint","First stable delivery")):ax.set_title(t,fontsize=11)
fig.savefig(HERE/"paper"/"correction_examples.jpg",dpi=140,bbox_inches="tight")
env.close()
