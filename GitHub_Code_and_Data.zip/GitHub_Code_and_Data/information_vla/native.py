"""Common native LIBERO fixtures, outcome definitions and paired intervention snapshots."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "vla_pilot"))
from run import (BOWL, TARGETS, LIB, Policy, OffScreenRenderEnv, at, digest, held,
                 instruction, reseed, reset_to_start)

CHEESE = "cream_cheese_1"
OBJECTS = (BOWL, CHEESE)
DESTINATIONS = ("plate", "stove")
ARMS = ("confirm", "destination", "object")
SCENE = "put_the_bowl_on_the_plate"


def make_env():
    return OffScreenRenderEnv(bddl_file_name=str(LIB / f"bddl_files/libero_goal/{SCENE}.bddl"),
                              camera_heights=256, camera_widths=256, ignore_done=True, hard_reset=True)


def grabbed(env, obj):
    return bool(env.env._check_grasp(env.env.robots[0].gripper, env.env.get_object(obj)))


def landed(env, obj, dest):
    return bool(env.env._eval_predicate(["on", obj, TARGETS[dest]])) and not grabbed(env, obj)


def target(original, arm):
    return int(arm == "object"), original ^ int(arm == "destination")


def sentences(original, arm):
    obj, dest = target(original, arm)
    old = instruction(DESTINATIONS[original])
    corr = {"object":"use the cream cheese instead", "confirm":"yes keep going",
            "destination":"on the " + DESTINATIONS[dest] + " instead"}[arm]
    full = "put the " + ("cream cheese" if obj else "bowl") + " on the " + DESTINATIONS[dest]
    return old, corr, full


def position(env, obs, obj):
    return env.sim.data.body_xpos[env.env.obj_body_id[obj]].copy()


def site(env, obs, dest):
    return (position(env, obs, "plate_1") if dest == 0 else
            np.asarray(env.sim.data.get_site_xpos(TARGETS["stove"])).copy())


def jsonline(path, row):
    with path.open("a", encoding="utf-8") as out:
        out.write(json.dumps(row) + "\n")


def snap_path(seed, orig, stage):
    return HERE / "snapshots" / f"{seed}_{orig}_{stage}.npz"

_blank_frame = np.zeros((256,256,3),dtype=np.uint8)

def step_visual(env,action,need_image):
    # Retain the sensor sampling clock; skip OpenGL only for frames discarded by the policy.
    for name in ("agentview_image","robot0_eye_in_hand_image"):
        sensor=env.env._observables[name]
        if not hasattr(sensor,"_full_camera_sensor"):
            sensor._full_camera_sensor=sensor._sensor
        sensor._sensor=sensor._full_camera_sensor if need_image else blank_sensor
    return env.step(action)[0]

def blank_sensor(cache):
    return _blank_frame
blank_sensor.__modality__="image"


def restore(env, path):
    with np.load(path) as z:
        seed = int(z["seed"])
        for attempt in range(4):
            obs = reset_to_start(env, z["initial"], seed)
            actions=z["actions"]
            for ix,a in enumerate(actions):
                obs = step_visual(env,a,ix==len(actions)-1)
            if digest(env, obs) == str(z["signature"]):
                return obs, z["home"].copy()
        raise RuntimeError(f"Unmatched replay {path.name}")


def encode_obs(obs):
    from robosuite.utils.transform_utils import quat2axisangle
    p = np.r_[obs["robot0_eef_pos"], quat2axisangle(obs["robot0_eef_quat"].copy()), obs["robot0_gripper_qpos"]]
    return (obs["agentview_image"][::-1,::-1].copy(), obs["robot0_eye_in_hand_image"][::-1,::-1].copy(), p.astype("f"))


def collect(seeds):
    folder = HERE / "snapshots"
    folder.mkdir(exist_ok=True)
    log = folder / "eligibility.jsonl"
    finished = {(r["seed"], r["orig"]) for r in map(json.loads,log.read_text().splitlines())} if log.exists() else set()
    states = torch.load(LIB / f"init_files/libero_goal/{SCENE}.pruned_init", weights_only=False)
    torch.set_num_threads(2)
    policy, env = Policy(10), make_env()
    try:
        for seed in seeds:
            for orig, dest in enumerate(DESTINATIONS):
                if (seed, orig) in finished:
                    continue
                obs = reset_to_start(env, states[seed], seed)
                home = position(env, obs, BOWL)
                reseed(1000 + seed)
                policy.reset()
                acts, status, good = [], {}, 0
                for stage in ("grasp", "near"):
                    reached = False
                    if stage == "near":
                        reseed(2000 + seed)
                        policy.reset()
                    for _ in range(180):
                        a = policy.act(obs, instruction(dest))
                        acts.append(a.copy())
                        obs = env.step(a)[0]
                        pos = position(env, obs, BOWL)
                        good = good + 1 if held(env) and pos[2] > home[2] + .015 else 0
                        if stage == "grasp":
                            reached = good >= 3
                        else:
                            reached = (held(env) and not at(env,dest) and
                                       np.linalg.norm(pos[:2]-site(env,obs,orig)[:2]) <= .06)
                        if reached or at(env,dest) and not held(env):
                            break
                    status[stage] = bool(reached)
                    if not reached:
                        break
                    np.savez_compressed(snap_path(seed,orig,stage),seed=seed,initial=states[seed],actions=acts,
                                        home=home,signature=digest(env,obs))
                row = dict(seed=seed,orig=orig,**status)
                jsonline(log,row)
                print(row,flush=True)
    finally:
        env.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("seeds",type=int,nargs="+")
    collect(parser.parse_args().seeds)
