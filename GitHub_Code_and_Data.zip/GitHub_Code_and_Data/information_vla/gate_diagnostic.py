"""Read out the two supervised edit gates on the six standard command pairs."""
import csv
from pathlib import Path

import torch

from adapter import FlowAdapter, lex
from native import ARMS, sentences

ROOT = Path(__file__).resolve().parent


def main():
    rows = []
    for seed in (33, 34, 35):
        for method in ("role", "paired"):
            checkpoint = torch.load(ROOT / "weights" / f"{seed}_{method}.pt", weights_only=True, map_location="cpu")
            model = FlowAdapter(checkpoint["width"], method).eval()
            model.load_state_dict(checkpoint["state"])
            for original in (0, 1):
                for arm in ARMS:
                    old, edit, _ = sentences(original, arm)
                    with torch.no_grad():
                        probs = model.gate(torch.tensor(lex(old, edit))).sigmoid().tolist()
                    truth = (arm == "object", arm == "destination")
                    rows.append(dict(seed=seed, method=method, original_site=original,
                                     edit=arm, object_gate=probs[0], destination_gate=probs[1],
                                     object_target=int(truth[0]), destination_target=int(truth[1]),
                                     exact_mask=int(tuple(v >= 0.5 for v in probs) == truth)))
    with (ROOT / "gate_diagnostic.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Exact edit masks on the six standard strings per fit: {sum(r['exact_mask'] for r in rows)}/{len(rows)}")


if __name__ == "__main__":
    main()
