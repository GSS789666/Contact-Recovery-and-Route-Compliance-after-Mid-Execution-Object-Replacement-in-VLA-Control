"""Build paper tables and figures directly from validated simulator results."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
PAPER = ROOT / "paper"
KITCHEN = ROOT.parent / "iteration2"
BASKET = ROOT.parent / "iteration3"


def read(path):
    return json.loads(path.read_text(encoding="utf8"))


old = read(KITCHEN/"results.json")
recent = {s:read(BASKET/f"{s}_results.json") for s in ("timing","transfer","routes")}
oldrows = {(r["tag"],r["edit"]):r for r in old["counts"]}


def table(key, caption, headings, entries, colspec=None):
    declaration = colspec or "l" + "r"*(len(headings)-1)
    cells = [" & ".join(str(x) for x in line) + r"\\" for line in entries]
    lines = [r"\begin{table}[htbp]", rf"\caption{{{caption}}}\label{{tab:{key}}}",
             r"\centering\small\setlength{\tabcolsep}{5pt}",rf"\begin{{tabular}}{{{declaration}}}",
             r"\toprule"," & ".join(headings)+r"\\",r"\midrule",*cells,r"\bottomrule",
             r"\end{tabular}",r"\end{table}"]
    return "\n".join(lines)+"\n"


def count(r,k="success"):
    return f"{r[k]}/{r['n']}"


def write_tables():
    assert old["rollouts"] == 599 and [recent[k]["executed"] for k in recent] == [270,192,150]
    groups = [
         ("A. Direct projection","Kitchen","14--25","39/48","11","429"),
         ("B. Flow projection","Kitchen","26--35","34/40","10","170"),
         ("C. Timing feedback","Kitchen","36--49","45/56","14","270"),
         ("D. Scene adaptation","Basket","8--19","24/24","12","192"),
         ("E. Route compliance","Basket","20--35","15/16","15","150"),
    ]
    entries = {"groups":table("groups",
        "Held-out simulation groups. Eligible interruptions are counted before assigning edits or methods. D tests two replacement objects and E tests two route requests from each qualified state. A includes confirmation and destination edits, measured once per shared route.",
        ["Group","Scene","Layout IDs","Eligible","Layouts","Rollouts"],groups,"llrrrr")}
    A = (("Complete-goal residual","canonicaltest"),("Ordinary residual","ordinarytest"),
         ("Direct contact projection","closure"),("Demonstration clock","timing"),
         ("Fixed landmark means","means"),("Geometry center","onlyservo"),
         ("Privileged geometry witness","witness"),("Contact projection, gain 0.65","slowevent"),
         ("Demonstration clock, gain 0.65","slowclock"))
    entries["A"] = table("A", "Kitchen direct projection (group A). Object substitution is scored at the first stable delivery.",
                         ["Controller","Correct","Wrong","Timeout","Median steps"],
                         [(name,count(r),r["wrong"],r["timeout"],f"{r['median_steps']:g}")
                          for name,tag in A for r in [oldrows[tag,"object"]]])
    C = recent["timing"]["methods"]
    timing_names = [("Fixed clock","clock"),("Speed-compensated clock","compensated"),("Spatial progression","event")]
    entries["C"] = table("C",
        "Timing feedback in group C. Counts for stable regrasp and lift are descriptive, extracted from the archived trajectory. The perturbation is a temporary 0.45 translation multiplier.",
        ["Condition and controller","Correct","Regrasp","Lift","Timeout"],
        [(condition + " / "+name,count(r),r["regrasp"],r["lift"],r["timeout"])
         for condition in ("Nominal","Transient") for name,k in timing_names for r in [C[condition.lower()+"/"+k]]])
    D = recent["transfer"]["methods"]
    entries["D"] = table("D","First correct basket delivery after replacement (group D). The same 48 target-specific continuations enter each arm.",
        ["Controller","Correct","Butter","Tomato sauce","Wrong","Timeout"],
        [(name,count(r),count(r["by_object"]["butter"]),count(r["by_object"]["tomato"]),r["wrong_delivery"],r["timeout"])
         for name,key in (("Complete-goal residual","canonical"),("Output projection","late"),("RGB geometry","geometry"),
                          ("Fixed-landmarks geometry","mean")) for r in [D[key]]])
    E = recent["routes"]["methods"]
    entries["E"] = table("E","Route and delivery outcomes (group E). Left and right columns require both a correct approach and a correct delivery.",
        ["Controller","Delivery","Left","Right","Joint"],
        [(name,count(r,"delivery"),count(r["by_requested_side"]["left"]),count(r["by_requested_side"]["right"]),count(r))
         for name,key in (("Parsed-side geometry","geometry"),("Behavior cloning","bc"),("VLA output projection","late"),
                          ("VLA within-flow projection","inside"),("Output, reversed wording","swapped")) for r in [E[key]]])
    for key,value in entries.items():
        (PAPER/f"table_{key}.tex").write_text(value,encoding="utf8")


def extract(r):
    return (r["effect_pp"],*r.get("interval_pp",[r.get("lo_pp"),r.get("hi_pp")]))


def effect_figure():
    A=old["contrasts"]
    C,D,E=[recent[k]["effects"] for k in ("timing","transfer","routes")]
    spec=[
        ("A  Direct vs full goal",A["closure-canonicaltest"]),
        ("A  Direct vs ordinary residual",A["closure-ordinarytest"]),
        ("A  Direct vs RGB geometry",A["closure-onlyservo"]),
        ("C  Compensated vs fixed clock",C["transient/compensated-clock"]),
        ("C  Compensated vs spatial triggering",dict(effect_pp=-C["transient/event-compensated"]["effect_pp"],
                                   interval_pp=[-x for x in reversed(C["transient/event-compensated"]["interval_pp"])])),
        ("D  Output projection vs full goal",D["late-canonical"]),
        ("D  Output projection vs RGB geometry",D["late-geometry"]),
        ("E  Output projection vs side rule",E["late-geometry"]),
    ]
    fig,ax=plt.subplots(figsize=(7.4,3.45),layout="constrained")
    colors={"A":"#1a5269","C":"#916037","D":"#408266","E":"#7d518b"}
    for i,(label,r) in enumerate(spec):
        val,lo,hi=extract(r)
        c=colors[label[0]]
        ax.hlines(i,lo,hi,color=c,lw=1.55)
        ax.scatter(val,i,s=23,color=c,zorder=3)
    for y in (2.5,4.5,6.5):
        ax.axhline(y,c="#d6dcde",lw=.65)
    ax.axvline(0,c="#52606a",lw=.9,ls="--")
    ax.set_yticks(range(len(spec)),[label for label,_ in spec],fontsize=8.7)
    ax.set_xticks([-100,-75,-50,-25,0,25,50,75,100])
    ax.set_xlim(-106,106)
    ax.set_ylim(len(spec)-.55,-.55)
    ax.set_xlabel("Difference in layout-balanced success (percentage points)",fontsize=9)
    ax.tick_params(axis="y",length=0)
    ax.spines[["top","right","left"]].set_visible(False)
    fig.savefig(PAPER/"integrated_effects.pdf")
    plt.close(fig)


def route_figure():
    logs = {
       "rule":BASKET/"runs/routecontrols",
       "vla":BASKET/"runs/routeoutput",
    }
    parsed = {key:[json.loads(l) for l in (path/"trials.jsonl").read_text().splitlines()] for key,path in logs.items()}
    rule = [r for r in parsed["rule"] if r["method"]=="geometry"]
    seed = min(r["seed"] for r in rule)
    fig, axs=plt.subplots(1,2,figsize=(7.6,2.55),sharey=True,layout="constrained")
    for ax,key,rows,label in ((axs[0],"rule",rule,"Explicit side rule"),(axs[1],"vla",parsed["vla"],"VLA output projection")):
        for side,c,style in [(-1,"#185268","-"),(1,"#a6532b","--")]:
            r=next(r for r in rows if r["seed"]==seed and r["requested_side"]==side)
            with np.load(logs[key]/(r["key"]+".npz")) as bundle:
                tr=bundle["trace"]
            start=int(np.flatnonzero(tr[:,21]==5)[0])
            stop=int(np.flatnonzero(tr[:,19]==1)[0])
            ax.plot(np.arange(stop-start),(tr[start:stop,11]-tr[start:stop,24])*1000,
                    label="Left requested" if side<0 else "Right requested",
                    color=c,ls=style,lw=1.5)
        ax.axhspan(32,78,color="#eef1f3")
        ax.axhspan(-78,-32,color="#eef1f3")
        ax.axhline(0,color="#607381",lw=.7)
        ax.set_ylim(-78,78)
        ax.set_title(label,fontsize=10)
        ax.set_xlabel("Controls after approach decision",fontsize=8.3)
        ax.spines[["top","right"]].set_visible(False)
    axs[0].set_ylabel("Signed lateral pad offset (mm)",fontsize=8.3)
    handles,labels=axs[0].get_legend_handles_labels()
    axs[0].legend(handles,labels,loc="upper center",fontsize=7,frameon=False)
    fig.savefig(PAPER/"route_traces.pdf")
    plt.close(fig)
    print("Route illustration uses lowest eligible layout",seed)


if __name__=="__main__":
    PAPER.mkdir(exist_ok=True)
    write_tables()
    effect_figure()
    route_figure()
    print("Five editable tables and two vector figures generated.")
