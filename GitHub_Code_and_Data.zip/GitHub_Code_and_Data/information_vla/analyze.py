"""Audit paired native rollouts, then generate journal tables and the result figure."""
import csv
import hashlib
import itertools
import json
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
PAPER=ROOT/"paper"
ARMS=("confirm","destination","object")
MODES=("frozen","ordinary","perfect","canonical","role","paired","teacher")
NAMES=dict(frozen="Frozen + full goal",ordinary="Ordinary residual",perfect="Exact fields",canonical="Full goal + residual",
           role="Role supervision",paired="Role + branch loss",teacher="Geometric witness")
def read(path): return [json.loads(s) for s in path.read_text().splitlines()]
def write_csv(path,rows):
    with path.open("w",newline="",encoding="utf-8-sig") as file:
        out=csv.DictWriter(file,fieldnames=list(rows[0]));out.writeheader();out.writerows(rows)
def pct(v): return f"{100*v:.1f}"
def goal(orig,arm): return (int(arm=="object"),orig^int(arm=="destination"))
def layout_scores(rows):
    return np.array([np.mean([r["success"] for r in rows if r["seed"]==i]) for i in range(8,14)])
def contrast(a,b):
    v=layout_scores(a)-layout_scores(b)
    indices=np.array(list(itertools.product(range(6),repeat=6)))
    lo,hi=np.quantile(v[indices].mean(1),[.025,.975])
    return {"difference":v.mean(),"lo":lo,"hi":hi,"values":v.tolist()}


def main():
    P=PAPER
    all_rows=[]
    for path in sorted((ROOT/"evaluation").glob("*.jsonl")):
        for r in read(path):
            f=ROOT/"evaluation"/r["trace"]
            with np.load(f) as a:
                tr=a["trace"]
                assert tr.shape==(r["steps"],16) and np.isfinite(tr).all()
                lift=float(np.max(tr[:,15])-tr[0,15])
            correct=goal(r["orig"],r["arm"])
            end=tuple(r["end"]) if r["end"] is not None else None
            assert r["success"]==(correct==end)
            assert end is not None or r["steps"]==180
            with np.load(ROOT/"snapshots"/f'{r["seed"]}_{r["orig"]}_{r["stage"]}.npz') as z:
                assert r["snapshot"]==str(z["signature"])
            if r["method"] not in ("teacher","frozen"):
                checkpoint=ROOT/"weights"/f'{r["fit_seed"]}_{r["method"]}.pt'
                assert r["weight_sha256"]==hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            r.update(target_object=correct[0],target_destination=correct[1],endpoint="timeout" if end is None else f"{end[0]}-{end[1]}",
                     cheese_rise_m=lift,source=path.name)
            all_rows.append(r)
    groups=defaultdict(list)
    for r in all_rows: groups[(r["method"],r["fit_seed"])].append(r)
    eligrows=read(ROOT/"snapshots/eligibility.jsonl")
    keys={(r["seed"],r["orig"],stage,arm) for r in eligrows if r["seed"]>=8 for stage in ("grasp","near")
          if r.get(stage,False) for arm in ARMS}
    expected={(m,None) for m in ("teacher","frozen")}|{(m,s) for m in ("ordinary","perfect","role","paired") for s in (33,34,35)}|{("canonical",33)}
    assert set(groups)==expected,(set(groups),expected)
    for name,rows in groups.items():
        assert len(rows)==len(keys) and {(r["seed"],r["orig"],r["stage"],r["arm"]) for r in rows}==keys,name
    write_csv(ROOT/"heldout_rollouts.csv",all_rows)
    primary={m:groups[m,None if m in ("teacher","frozen") else 33] for m in MODES}
    summary=[]
    for (m,fit),rows in groups.items():
        entry=dict(method=m,fit_seed=fit,n=len(rows),success=sum(r["success"] for r in rows),
                   macro=layout_scores(rows).mean(),timeouts=sum(r["end"] is None for r in rows))
        for arm in ARMS:
            ss=[r for r in rows if r["arm"]==arm]
            entry[arm]=sum(r["success"] for r in ss)
        for stage in ("grasp","near"):
            ss=[r for r in rows if r["stage"]==stage]
            entry[stage]=sum(r["success"] for r in ss)
        summary.append(entry)
    write_csv(ROOT/"heldout_summary.csv",summary)
    layout_rows=[]
    for (method,seed),rows in groups.items():
        for layout in range(8,14):
            cases=[r for r in rows if r["seed"]==layout]
            layout_rows.append(dict(method=method,fit_seed=seed,layout=layout,branches=len(cases),
                                    success=sum(r["success"] for r in cases),
                                    wrong_delivery=sum(not r["success"] and r["end"] is not None for r in cases),
                                    timeout=sum(r["end"] is None for r in cases)))
    write_csv(ROOT/"layout_scores.csv",layout_rows)
    result={"rollouts":len(all_rows),"cases":len(keys),"contrasts":{},"training":{}}
    for m in ("ordinary","perfect","canonical","role","frozen"):
        result["contrasts"][m]=contrast(primary["paired"],primary[m])
    result["secondary_full_goal_vs_exact_fields"]=contrast(primary["canonical"],primary["perfect"])
    for split,lo,hi in (("train",0,5),("dev",6,7)):
        demo=[r for r in read(ROOT/"demos_v2/trials.jsonl") if r["arm"]!="object"]
        demo+=read(ROOT/"demos_regrasp/trials.jsonl")
        demo=[r for r in demo if lo<=r["seed"]<=hi]
        cnt={}
        for a in ARMS:
            rr=[r for r in demo if r["arm"]==a]
            cnt[a]=[sum(r["success"] for r in rr),len(rr),sum(r["success"] and r["steps"]<=50 for r in rr)]
        result["training"][split]=cnt
    (ROOT/"estimates.json").write_text(json.dumps(result,indent=2))
    def rowdata(m,s): return next(r for r in summary if r["method"]==m and r["fit_seed"]==s)
    rows=[]
    for m in MODES:
        r=rowdata(m,None if m in ("teacher","frozen") else 33)
        rows.append(" & ".join([NAMES[m],*[str(r[a]) for a in ARMS],f'{r["success"]}/{r["n"]}',pct(r["macro"]),str(r["timeouts"])])+r" \\")
    (P/"main_rows.tex").write_text("\n".join(rows))
    rows=[]
    for m in ("ordinary","perfect","role","paired"):
        cell=[rowdata(m,s) for s in (33,34,35)]
        rows.append(" & ".join([NAMES[m],*[pct(r["macro"]) for r in cell],pct(np.mean([r["macro"] for r in cell]))])+r" \\")
    (P/"seed_rows.tex").write_text("\n".join(rows))
    rows=[]
    for m in MODES:
        rr=primary[m]
        for s in ("grasp","near"):
            for a in ARMS:
                subset=[r for r in rr if r["arm"]==a and r["stage"]==s]
                rows.append(dict(method=m,stage=s,edit=a,n=len(subset),successful=sum(r["success"] for r in subset),
                                 timeouts=sum(r["end"] is None for r in subset),
                                 wrong_delivery=sum(not r["success"] and r["end"] is not None for r in subset)))
    write_csv(ROOT/"stage_edit_cells.csv",rows)
    mat=np.array([[next(r["successful"]/r["n"] for r in rows if r["method"]==m and r["stage"]==s and r["edit"]==a)
                 for s in ("grasp","near") for a in ARMS] for m in MODES])
    fig,ax=plt.subplots(figsize=(8.5,4.3),layout="constrained")
    ax.imshow(mat,aspect="auto",cmap="Blues",vmin=0,vmax=1)
    ax.set_xticks(range(6),["Confirm","New site","New item"]*2)
    ax.set_yticks(range(len(MODES)),[NAMES[m] for m in MODES])
    for i,m in enumerate(MODES):
        for j,(s,a) in enumerate(itertools.product(("grasp","near"),ARMS)):
            cell=next(r for r in rows if r["method"]==m and r["stage"]==s and r["edit"]==a)
            ax.text(j,i,f'{cell["successful"]}/{cell["n"]}',ha="center",va="center",color="white" if mat[i,j]>.55 else "#142532")
    ax.axvline(2.5,color="white",lw=3)
    top=ax.secondary_xaxis("top");top.set_xticks([1,4],["First stable grasp","Near original site"]);top.tick_params(length=0,pad=8)
    for spine in ax.spines.values():spine.set_visible(False)
    ax.tick_params(length=0)
    fig.savefig(P/"stage_results.pdf",bbox_inches="tight");plt.close(fig)
    print(json.dumps(result,indent=2))

if __name__=="__main__":main()
