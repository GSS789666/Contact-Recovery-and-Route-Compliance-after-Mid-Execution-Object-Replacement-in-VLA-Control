# Reproducing the closed-loop study on the Windows workstation

The manuscript uses an adapted pretrained SmolVLA checkpoint in native LIBERO throughout the main study. The compact action adapter, role-only ablation, ordinary matched adapter, exact-field adapter and complete-goal adapter are in adapter.py. The manually specified English phrase indicators are part of the system. The frozen complete-goal comparator retains its original language pathway. The separate teacher reads simulator geometry for demonstration generation and feasibility assessment.

## Inputs

Use the isolated Python environment, pinned public model and scene assets listed in [the pilot runtime notes](../vla_pilot/runtime.md) and [environment versions](../vla_pilot/environment.json). The tested host is Windows with CUDA. The model revision is a24f1f380461b665158d52acd140152c79e8b36d and its weight SHA-256 is 9a9f6413e42c0f332fccbce9a0dc796af2790f82cf002f791cdbf7e01e1afca8. The code imports the original policy wrapper from the sibling vla_pilot directory. The official object-on-region predicates are evaluated on the bowl-on-plate scene. A derivative task requires moving cream cheese to the original requested site. Local files use the public benchmark initial-state indices. The four-layout pilot is documented independently in vla_pilot.

Use a new copy of the study scripts with empty output directories for a new full run. Some programs support resuming their own completed rows. Checkpoint selection uses only layouts 6 and 7. Execution time and memory requirements depend on local hardware and the number of active processes.

## Commands

Run these commands in PowerShell from the parent of information_vla. After generating the five heads, the evaluation coordinator launches two workers at a time. Only successful final-checkpoint runs should be included in the aggregate evaluation directory.

~~~powershell
$studyPython = "$env:LOCALAPPDATA/vla-pilot/venv/Scripts/python.exe"
& $studyPython -u information_vla/native.py 0 1 2 3 4 5 6 7 8 9 10 11 12 13
& $studyPython -u information_vla/demonstrations.py 0 1 2 3 4 5 6 7 --arms confirm destination --folder demos_v2
& $studyPython -u information_vla/demonstrations.py 0 1 2 3 4 5 6 7 --arms object --folder demos_regrasp
& $studyPython -u information_vla/fit.py --seeds 33 34 35
& $studyPython -u information_vla/fit.py --canonical --seeds 33
& $studyPython -u information_vla/evaluate.py --methods frozen --tag frozen
& $studyPython -u information_vla/evaluate.py --methods teacher --tag teacher
& ./information_vla/run_evaluations.ps1
& $studyPython information_vla/analyze.py
~~~

On the original workstation the first geometric-generation pass also evaluated an earlier cheese acquisition routine. fit.py explicitly excludes all of its object trials and uses only the revised object trajectories in demos_regrasp. The supplement includes the final training inputs and failure records. Historical development attempts are not used to estimate test performance. Stored feature caches are regenerable. A cached tensor bank binds the demonstration hash, frozen backbone revision, extraction version and language pathway. Trained-policy evaluation rows store the checkpoint hash and training seed. No paid API or external VLM is used during training or deployment.

## Output records

- snapshots/eligibility.jsonl gives the status of each initial state and original direction, including failures before intervention. Each snapshot file contains the original physical state, replayed action prefix, layout index, bowl home position and the joint physical/camera checksum.
- The training demonstration files contain both camera images and proprioception at each ten-step sampling point, together with all seven-channel actions. The teacher logs record attempts, terminal pairs, steps and successful data filenames.
- weights contains the trained residuals, minimum-development-error epoch and full development histories. At evaluation time the original pretrained weights are frozen.
- evaluation contains trial-level JSON and aligned movement files. Trace columns 0–6 are commanded actions, 7–9 end-effector xyz, 10–12 bowl xyz and 13–15 cheese xyz in metres. Endpoint codes encode bowl or cheese (0 or 1), then plate or stove (0 or 1). A null endpoint denotes timeout.
- analyze.py independently checks that all methods cover the same eligible branches, that snapshot and checkpoint identities agree, that trace lengths and numeric values are valid, and that the stored success flags match the required pair. It exports heldout_rollouts.csv, heldout_summary.csv, stage_edit_cells.csv, estimates.json, the manuscript tables and the stage-by-edit figure.
- The optional diagnostics gate_diagnostic.py and replay_audit.py read the trained edit gates and re-execute nine recorded trajectories in the native simulator, respectively. Compare the output to gate_diagnostic.csv and measured_replay.csv.
- The English manuscript uses the official Information LaTeX template. For local Tectonic compatibility the MDPI logo was taken as a vector form from the same official template PDF, and the local class points to its equivalent PDF graphic. Authors can compile article.tex with its included dependencies. The official template and logo are intended for the journal submission workflow.
