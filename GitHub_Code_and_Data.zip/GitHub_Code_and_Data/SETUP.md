# Installation and verification

## Reporting only

The archive includes the data needed to rebuild all reported tables. Use Python 3.11, NumPy and Matplotlib. Extract the entire repository before running the analysis from its root. The outputs are written to information_vla and information_vla/paper.

~~~text
python -m pip install numpy==1.26.4 matplotlib==3.11.2
python information_vla/analyze.py
~~~

## Full simulation and policy fitting

The recorded platform is native Windows, Python 3.11.9, an NVIDIA RTX 5060 Laptop GPU, CUDA-enabled PyTorch 2.11.0+cu128, torchvision 0.26.0+cu128 and an OpenGL driver supporting GLFW. The training scripts expect CUDA. reporting-only runs have no such dependency. The tested environment was an isolated interpreter with access to existing numerical packages. The versions in runtime-versions.tsv are a record of that installation, not a lock file from a fresh dependency solve. In particular the tested PyTorch, torchvision and draccus versions are newer than the version ranges in LeRobot 0.4.4 metadata. Blindly resolving all pinned packages together will produce a conflict.

1. Create a dedicated environment at %LOCALAPPDATA%/vla-pilot/venv, and install a CUDA build of PyTorch and torchvision appropriate for the workstation. The local reference path uses PyTorch 2.11.0 and torchvision 0.26.0 from the cu128 wheel index. Install the recorded simulator, numerical, Hugging Face, tokenization and rendering dependencies listed in runtime-versions.tsv. Preserve the tested numerical stack when placing the lerobot==0.4.4 code into that environment (pip's --no-deps switch is available for an already provisioned environment). The scientific scripts use the SmolVLA policy module, not LeRobot's full training CLI.
2. Install hf-libero 0.1.5 to obtain the BDDL and initial-state files. Acquire the complete assets directory from [the exact LIBERO commit used here](https://github.com/Lifelong-Robot-Learning/LIBERO/tree/8f1084e3132a39270c3a13ebe37270a43ece2a01/libero/libero/assets). Expose it as Lib/site-packages/libero/libero/assets in the dedicated environment. Both movable objects, both sites, collision geometry and textures are required. Preserve the repository hierarchy.
3. For the Windows robosuite 1.4.0 environment use the installed MuJoCo package directory to resolve mujoco.dll. The Windows ctypes.WinDLL call in robosuite/utils/binding_utils.py used os.path.join(os.path.dirname(mujoco.__file__), "mujoco.dll"). In the same environment set robosuite/macros.py FILE_LOGGING_LEVEL to None and MUJOCO_GPU_RENDERING to False. Use MUJOCO_GL=glfw and leave the image convention at opengl.
4. From the repository root run the fixed-revision downloader vla_pilot/fetch_policy.py with that interpreter. It prepares the tokenizer, architecture files, policy weights and normalization statistics under %LOCALAPPDATA%/vla-pilot. The expected policy weight SHA-256 is 9a9f6413e42c0f332fccbce9a0dc796af2790f82cf002f791cdbf7e01e1afca8.
5. Inspect vla_pilot/environment.json and run the snapshot, fitting and evaluation commands in [the experiment protocol](information_vla/REPRODUCE.md) from a fresh output copy. To audit existing results without refitting, keep the distributed files and run only analyze.py. The full run was verified on the configured workstation. Compatibility on another operating system or GPU must be checked independently, including byte-identical snapshot replay.

The released compact .pt files are action residuals. A residual requires the indicated base checkpoint. State indices, eligibility logs, traces and bootstrap estimates are independent of model download once generated.
