# Mid-execution corrections in robot manipulation

This repository accompanies the study by Shengshuo Gong and Oleg O. Varlamov at Bauman Moscow State Technical University. It contains the code and local experiment records for a paired study of frozen and adapted SmolVLA policies in LIBERO. A robot holding a bowl receives one of three requests: continue, change the placement site, or replace the bowl with cream cheese while preserving the original placement site.

[Watch the nine-second native replay](information_vla/paper/heldout_replay.mp4). The frozen model, complete-goal residual and geometric teacher start from the same held-out snapshot and receive the same effective object correction. The moving panels follow the original control clock. A panel holds its final frame after a terminal delivery.

## Start with the measurements

- [Trial-level outcomes](information_vla/heldout_rollouts.csv) and [summary by method and training seed](information_vla/heldout_summary.csv).
- [Intervention-stage and edit-type breakdown](information_vla/stage_edit_cells.csv), [layout-paired effect estimates](information_vla/estimates.json), and [language encoding diagnostic](information_vla/interface_probe.csv).
- [Per-layout counts](information_vla/layout_scores.csv), [trained edit-gate readout](information_vla/gate_diagnostic.csv), and [physical replay audit](information_vla/measured_replay.csv).
- [Eligibility of each public layout and original direction](information_vla/snapshots/eligibility.jsonl). Each stored snapshot has a replay prefix and a checksum of the simulated state and its two camera observations.
- [Primary outcome figure](information_vla/paper/stage_results.pdf) and [training example](information_vla/paper/correction_examples.jpg).
- [Earlier, four-layout pilot](vla_pilot/all_trials.csv). Its development layouts overlap the follow-up training split.

## Recalculate the results

For the reporting step, install NumPy and Matplotlib. From the repository root run:

~~~text
python information_vla/analyze.py
~~~

The script audits checkpoint identities, branch coverage, trace lengths and scoring before regenerating the tables, CSV files and figure. No simulator, pretrained model download or GPU is needed for this step. Use Python 3.11 with NumPy 1.26.4 and Matplotlib 3.11.2 to match the recorded reporting environment. The SHA256SUMS file covers the distributed files before regeneration.

## Reproduce the robot experiment

See [setup and execution](SETUP.md) and [commands and data schema](information_vla/REPRODUCE.md). The package includes the compact trained action residuals, per-layout demonstration images and controls, and all held-out trajectories. Public foundation weights, original third-party source distributions and meshes are obtained from their upstream releases. See [upstream sources](THIRD_PARTY.md).

The evaluation horizon is 180 control steps. The first stable object--destination pair among the registered sites determines success. Setting the bowl on the ordinary table during object replacement is allowed. Layouts 0–5 supply training trajectories, 6–7 select weights, and 8–13 provide the held-out comparison. The word interface uses a finite grammar. Geometry-based demonstrations read simulator state; learned policies receive images, proprioception and text-derived features.

## Layout

~~~text
information_vla/
  native.py, demonstrations.py     snapshots, scoring and expert continuations
  adapter.py, fit.py               action flow residuals and training
  evaluate.py, analyze.py          closed-loop rollouts and paired analysis
  snapshots/                       replay inputs and eligibility
  demos_v2/, demos_regrasp/         final demonstration inputs and attempt logs
  weights/, evaluation/            selected weights, trajectories and outcomes
vla_pilot/                         original policy wrapper and pilot evidence
~~~
