# Upstream sources

- [LIBERO](https://github.com/Lifelong-Robot-Learning/LIBERO) provides the benchmark assets, task definitions, initial states and predicates. The runner uses the hf-libero 0.1.5 distribution.
- [robosuite](https://github.com/ARISE-Initiative/robosuite) and [MuJoCo](https://github.com/google-deepmind/mujoco) provide simulation and low-level control.
- [LeRobot](https://github.com/huggingface/lerobot) provides the SmolVLA implementation. The checkpoint is [lerobot/smolvla_libero at revision a24f1f3](https://huggingface.co/lerobot/smolvla_libero/tree/a24f1f380461b665158d52acd140152c79e8b36d); the tokenizer/config source is [SmolVLM2-500M-Video-Instruct](https://huggingface.co/HuggingFaceTB/SmolVLM2-500M-Video-Instruct/tree/4cde9d208e19519c36917aa170fffc7e381aa0ad).
- Model cards, licenses and asset provenance remain with the respective upstream releases. The pretrained checkpoint and the original mesh files are not included in this package. The study's stored camera frames are observations rendered in LIBERO, and the public state identifiers refer to its benchmark.
