"""Replay the pilot's paired grasp states for wording and intervention-time controls."""
import argparse
import json
import random
import time
from pathlib import Path

import numpy as np
import torch

from run import (BOWL, LIB, TARGETS, OffScreenRenderEnv, Policy, at, digest, episode,
                 held, instruction, record, reseed, reset_to_start)


def replay(env, initial, seed, actions, checksum):
    obs = reset_to_start(env, initial, seed)
    for action in actions:
        obs = env.step(action)[0]
    if digest(env, obs) != checksum:
        raise RuntimeError(f"Replay mismatch for seed {seed}")
    return obs


def run_branches(env, policy, initial, prefix, checksum, case, commands, out, log):
    seed, original, goal = case["seed"], case["original"], case["goal"]
    items = list(commands.items())
    random.Random(807 + seed).shuffle(items)
    for arm, command in items:
        obs = replay(env, initial, seed, prefix, checksum)
        policy.reset()
        reseed(2000 + seed)
        target = original if arm == "late_continue" else goal
        result = episode(env, policy, obs, command, target, 180, out / f"{seed}_{original}_{arm}")
        record(log, {**case, "arm": arm, "snapshot": checksum, "text": command, **result})


def source_cases(log, seeds):
    for seed in seeds:
        for original in ("plate", "stove"):
            deadline = time.monotonic() + 600
            while time.monotonic() < deadline:
                # Read complete lines only when the primary experiment is still running.
                lines = log.read_bytes().split(b"\n")[:-1]
                rows = [json.loads(line) for line in lines]
                case = {r["arm"]: r for r in rows if r["seed"] == seed and r["original"] == original}
                if "prefix" in case and (not case["prefix"]["eligible"] or "continue" in case):
                    yield case["prefix"]
                    break
                time.sleep(3)
            else:
                raise TimeoutError(f"Primary trajectory unavailable: {seed} {original}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", required=True)
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True, parents=True)
    log = args.out / "trials.jsonl"
    if log.exists():
        raise FileExistsError(log)
    torch.set_num_threads(2)
    policy = Policy(10)
    scene = LIB / "bddl_files/libero_goal/put_the_bowl_on_the_plate.bddl"
    env = OffScreenRenderEnv(bddl_file_name=str(scene), camera_heights=256, camera_widths=256,
                             ignore_done=True, hard_reset=True)
    try:
        for row in source_cases(args.source / "trials.jsonl", args.seeds):
            if not row["eligible"]:
                continue
            case = {k: row[k] for k in ("seed", "original", "goal")}
            seed, original, goal = case["seed"], case["original"], case["goal"]
            with np.load(args.source / f"snapshot_{seed}_{original}.npz") as saved:
                initial, prefix = saved["initial"], saved["prefix"]
            run_branches(env, policy, initial, prefix, row["snapshot"], case, {
                "short_plain": f"on the {goal}",
                "full_instead": instruction(goal) + " instead",
            }, args.out, log)
            obs = replay(env, initial, seed, prefix, row["snapshot"])
            with np.load(args.source / f"{seed}_{original}_continue.npz") as saved:
                continuation = saved["actions_eef_bowl"][:, :7]
            for ticks, action in enumerate(continuation, 1):
                obs = env.step(action)[0]
                pos = (obs["plate_1_pos"] if original == "plate" else
                       env.sim.data.get_site_xpos(TARGETS["stove"]))
                distance = float(np.linalg.norm(obs[BOWL + "_pos"][:2] - pos[:2]))
                if distance <= 0.06 and held(env) and not at(env, original):
                    break
            else:
                record(log, {**case, "arm": "late_prefix", "eligible": False})
                continue
            late_id = digest(env, obs)
            late_actions = np.vstack([prefix, continuation[:ticks]])
            np.savez_compressed(args.out / f"late_snapshot_{seed}_{original}.npz",
                                initial=initial, prefix=late_actions, agentview=obs["agentview_image"],
                                wrist=obs["robot0_eye_in_hand_image"], physics=env.sim.get_state().flatten())
            record(log, {**case, "arm": "late_prefix", "eligible": True, "snapshot": late_id,
                         "extra_steps": ticks, "old_target_distance_m": distance})
            run_branches(env, policy, initial, late_actions, late_id, case, {
                "late_full": instruction(goal), "late_continue": instruction(original),
            }, args.out, log)
    finally:
        env.close()


if __name__ == "__main__":
    main()
