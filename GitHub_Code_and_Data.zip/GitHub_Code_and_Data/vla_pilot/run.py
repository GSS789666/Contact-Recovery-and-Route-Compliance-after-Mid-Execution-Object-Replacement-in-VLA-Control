"""Paired closed-loop LIBERO correction pilot. Run from the experiment directory."""
import argparse
import hashlib
import json
import os
import random
import sys
from pathlib import Path
from PIL import Image, ImageDraw

import numpy as np
import torch
import yaml
from safetensors.torch import load_file

ROOT = Path(os.environ.get("VLA_PILOT_HOME", Path(os.environ["LOCALAPPDATA"]) / "vla-pilot"))
LIB = Path(sys.prefix) / "Lib/site-packages/libero/libero"
os.environ["LIBERO_CONFIG_PATH"] = str(ROOT / "libero-config")
os.environ.setdefault("MUJOCO_GL", "glfw")
cfgdir = Path(os.environ["LIBERO_CONFIG_PATH"])
cfgdir.mkdir(exist_ok=True)
if not (cfgdir / "config.yaml").exists():
    (cfgdir / "config.yaml").write_text(yaml.safe_dump({k:str(LIB/v) for k,v in {
        "benchmark_root":".","bddl_files":"bddl_files","init_states":"init_files",
        "datasets":"../datasets","assets":"assets"}.items()}))

from libero.libero.envs import OffScreenRenderEnv
from lerobot.policies.smolvla.configuration_smolvla import SmolVLAConfig
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from transformers import AutoTokenizer

BOWL = "akita_black_bowl_1"
TARGETS = {"plate":"plate_1","stove":"flat_stove_1_cook_region"}

def instruction(dest):
    return f"put the bowl on the {dest}"

def reseed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

class Policy:
    def __init__(self, horizon):
        folder = ROOT / "policy"
        import draccus
        raw_config=json.loads((folder/"config.json").read_text())
        assert raw_config.pop("type")=="smolvla"
        config = draccus.decode(SmolVLAConfig,raw_config)
        config.vlm_model_name = str(ROOT / "vlm")
        config.load_vlm_weights = False
        self.model = SmolVLAPolicy(config)
        # safetensors omits shared tensors. Restore tied model pointers after loading.
        incompatible = self.model.load_state_dict(load_file(str(folder / "model.safetensors")), strict=False)
        params = dict(self.model.named_parameters(remove_duplicate=False))
        loaded_names = set(self.model.state_dict()) - set(incompatible.missing_keys)
        loaded_ptrs = {params[n].data_ptr() for n in loaded_names if n in params}
        missing = [n for n in incompatible.missing_keys if n not in params or params[n].data_ptr() not in loaded_ptrs]
        if missing or incompatible.unexpected_keys:
            raise ValueError((missing, incompatible.unexpected_keys))
        self.model.cuda().eval()
        self.horizon = horizon
        self.tokenizer = AutoTokenizer.from_pretrained(ROOT / "vlm")
        self.stats = load_file(str(next(folder.glob("*normalizer_processor.safetensors"))))
        self.reset()

    def reset(self):
        self.model.reset()
        self.queue = []

    @torch.inference_mode()
    def act(self, obs, command):
        if not self.queue:
            quat = torch.tensor(obs["robot0_eef_quat"],dtype=torch.float32)
            w = quat[3].clamp(-1,1)
            d = (1-w*w).clamp(min=0).sqrt()
            axis = quat[:3]*2*torch.acos(w)/d if d>1e-10 else torch.zeros(3)
            state = torch.cat([torch.as_tensor(obs["robot0_eef_pos"]),axis,torch.as_tensor(obs["robot0_gripper_qpos"])]).float()
            state = (state-self.stats["observation.state.mean"])/(self.stats["observation.state.std"]+1e-8)
            lang = self.tokenizer([command+"\n"], max_length=48, padding="max_length", truncation=True, return_tensors="pt")
            batch = {"observation.state":state[None].cuda(),"observation.language.tokens":lang.input_ids.cuda(),"observation.language.attention_mask":lang.attention_mask.bool().cuda()}
            for i,cam in enumerate(["agentview_image","robot0_eye_in_hand_image"],1):
                image = torch.from_numpy(obs[cam][::-1,::-1].copy()).permute(2,0,1).unsqueeze(0)
                batch[f"observation.images.camera{i}"] = image.cuda().float()/255
            actions = self.model.predict_action_chunk(batch)[0,:self.horizon].float().cpu()
            actions = actions*self.stats["action.std"]+self.stats["action.mean"]
            self.queue = list(actions.numpy())
        return self.queue.pop(0)

def held(env):
    base = env.env
    return bool(base._check_grasp(base.robots[0].gripper, base.get_object(BOWL)))

def at(env, goal):
    return bool(env.env._eval_predicate(["on",BOWL,TARGETS[goal]]))

def digest(env, obs):
    h = hashlib.sha256()
    for x in [env.sim.get_state().flatten(),obs["robot0_gripper_qpos"],obs["agentview_image"],obs["robot0_eye_in_hand_image"]]:
        h.update(np.ascontiguousarray(x).tobytes())
    return h.hexdigest()

def reset_to_start(env, initial, seed):
    reseed(seed)
    env.seed(seed)
    env.reset()
    obs = env.set_init_state(initial)
    for _ in range(10):
        obs = env.step([0,0,0,0,0,0,-1])[0]
    return obs

def replay_checked(env, initial, seed, prefix, state_id, snapshot_file, context):
    for attempt in range(1, 5):
        obs = reset_to_start(env, initial, seed)
        for action in prefix:
            obs = env.step(action)[0]
        if digest(env, obs) == state_id:
            return obs
        with np.load(snapshot_file) as saved:
            delta = np.max(np.abs(env.sim.get_state().flatten() - saved["physics"]))
            pixels = [np.count_nonzero(obs[k] != saved[s]) for k, s in
                      (("agentview_image", "agentview"), ("robot0_eye_in_hand_image", "wrist"))]
        print(f"Discarded replay {attempt} for {context}: physics max {delta:g}, camera byte differences {pixels}",flush=True)
    raise RuntimeError(f"Could not reconstruct snapshot for {context}")

def record(file, data):
    with file.open("a",encoding="utf8") as f:
        f.write(json.dumps(data,ensure_ascii=False)+"\n")
    print(json.dumps(data),flush=True)

def episode(env, policy, obs, command, goal, budget, trace_path):
    stable = {k:0 for k in TARGETS}
    traces, frames = [], []
    landed = "timeout"
    for t in range(budget):
        action = policy.act(obs,command)
        obs = env.step(action)[0]
        traces.append(np.r_[action,obs["robot0_eef_pos"],obs[BOWL+"_pos"]])
        if t % 15 == 0:
            frames.append(Image.fromarray(obs["agentview_image"][::-1,::-1]).resize((144,144)))
        for k in TARGETS:
            stable[k] = stable[k]+1 if at(env,k) and not held(env) else 0
        for k in TARGETS:
            if stable[k]>=3:
                landed=k
                break
        if landed != "timeout":
            break
    np.savez_compressed(trace_path.with_suffix(".npz"),actions_eef_bowl=np.stack(traces))
    frames.append(Image.fromarray(obs["agentview_image"][::-1,::-1]).resize((144,144)))
    strip=Image.new("RGB",(144*len(frames),170),"white")
    for index,frame in enumerate(frames):
        strip.paste(frame,(144*index,0))
    ImageDraw.Draw(strip).text((4,147), f"{command} | {landed} | {t+1} steps",fill="black")
    strip.save(trace_path.with_suffix(".jpg"))
    return {"landed":landed,"success":landed==goal,"steps":t+1}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds",type=int,nargs="+",required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--horizon",type=int,default=10)
    parser.add_argument("--steps",type=int,default=180)
    parser.add_argument("--resume",action="store_true")
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    log = args.out/"trials.jsonl"
    if log.exists() and not args.resume:
        raise FileExistsError(log)
    existing = {(r["seed"], r["original"], r["arm"]): r
                for r in map(json.loads,log.read_text().splitlines())} if log.exists() else {}
    torch.set_num_threads(2)
    policy=Policy(args.horizon)
    print("policy loaded",flush=True)
    scene="put_the_bowl_on_the_plate"
    env=OffScreenRenderEnv(bddl_file_name=str(LIB/f"bddl_files/libero_goal/{scene}.bddl"),
                           camera_heights=256,camera_widths=256,ignore_done=True,hard_reset=True)
    states=torch.load(LIB/f"init_files/libero_goal/{scene}.pruned_init",weights_only=False)
    try:
        for seed in args.seeds:
            initial=states[seed]
            for original,goal in [("plate","stove"),("stove","plate")]:
                base={"seed":seed,"original":original,"goal":goal}
                if (seed,original,"from_start") not in existing:
                    obs=reset_to_start(env,initial,seed)
                    policy.reset()
                    reseed(1000+seed)
                    record(log,{**base,"arm":"from_start","text":instruction(goal),**episode(env,policy,obs,instruction(goal),goal,args.steps,args.out/f"{seed}_{original}_from_start")})
                snapshot_file=args.out/f"snapshot_{seed}_{original}.npz"
                previous=existing.get((seed, original, "prefix"))
                if previous:
                    if not previous["eligible"]:
                        continue
                    state_id=previous["snapshot"]
                    with np.load(snapshot_file) as saved:
                        prefix=saved["prefix"]
                        assert np.array_equal(initial, saved["initial"])
                else:
                    obs=reset_to_start(env,initial,seed)
                    reseed(1000+seed)
                    policy.reset()
                    height=obs[BOWL+"_pos"][2]
                    prefix=[]
                    good=0
                    for t in range(args.steps):
                        action=policy.act(obs,instruction(original))
                        prefix.append(action.copy())
                        obs=env.step(action)[0]
                        good=good+1 if held(env) and obs[BOWL+"_pos"][2]>height+0.015 else 0
                        if good>=3:
                            break
                    state_id=digest(env,obs)
                    if good>=3:
                        np.savez_compressed(snapshot_file,initial=initial,prefix=np.stack(prefix),physics=env.sim.get_state().flatten(),agentview=obs["agentview_image"],wrist=obs["robot0_eye_in_hand_image"])
                    record(log,{**base,"arm":"prefix","steps":len(prefix),"eligible":good>=3,"snapshot":state_id})
                    if good<3:
                        continue
                texts={"continue":instruction(original),"short":f"on the {goal} instead","full":instruction(goal),
                       "history_short":f"{instruction(original)}. correction: on the {goal} instead"}
                arms=list(texts)
                random.Random(807+seed).shuffle(arms)
                for arm in arms:
                    if (seed,original,arm) in existing:
                        continue
                    obs=replay_checked(env,initial,seed,prefix,state_id,snapshot_file,(seed,original,arm))
                    policy.reset()
                    reseed(2000+seed)
                    result=episode(env,policy,obs,texts[arm],original if arm=="continue" else goal,args.steps,args.out/f"{seed}_{original}_{arm}")
                    record(log,{**base,"arm":arm,"text":texts[arm],"snapshot":state_id,**result})
    finally:
        env.close()

if __name__=="__main__":
    main()
