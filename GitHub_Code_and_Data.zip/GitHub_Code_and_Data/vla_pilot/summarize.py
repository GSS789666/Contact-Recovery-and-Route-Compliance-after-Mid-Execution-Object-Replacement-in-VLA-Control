"""Audit denominators, saved trajectories and pairs, then write compact data and an example."""
import csv
import json
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent


def load_cases(name):
    rows = [json.loads(line) for line in (ROOT / name / "trials.jsonl").read_text().splitlines()]
    cases = {}
    for row in rows:
        case = cases.setdefault((row["seed"], row["original"]), {})
        assert row["arm"] not in case, row
        case[row["arm"]] = row
        if "landed" in row:
            key = f'{row["seed"]}_{row["original"]}_{row["arm"]}'
            with np.load(ROOT / name / (key + ".npz")) as file:
                trace = file["actions_eef_bowl"]
                assert trace.shape == (row["steps"], 13) and np.isfinite(trace).all()
            assert (ROOT / name / (key + ".jpg")).is_file()
            dest = row["original"] if row["arm"] in {"continue", "late_continue"} else row["goal"]
            assert row["success"] == (row["landed"] == dest)
    return cases


def main():
    primary, probes = load_cases("paired"), load_cases("probes")
    assert set(primary) == {(s, o) for s in range(4) for o in ("plate", "stove")}
    eligible = {k for k, v in primary.items() if v["prefix"]["eligible"]}
    assert set(probes) == eligible
    oracle = [json.loads(s) for s in (ROOT / "oracle/trials.jsonl").read_text().splitlines()]
    late = {k for k, v in probes.items() if v["late_prefix"]["eligible"]}
    assert len(oracle) == len(late) and {(r["seed"],r["original"]) for r in oracle} == late
    for row in oracle:
        key = (row["seed"],row["original"])
        assert row["snapshot"] == probes[key]["late_prefix"]["snapshot"]
        assert row["success"] == (row["goal"] == row["landed"])
        with np.load(ROOT / "oracle" / f'{key[0]}_{key[1]}.npz') as saved:
            trace = saved["actions_eef_bowl"]
            assert trace.shape == (row["steps"],13) and np.isfinite(trace).all()
    records = []
    for key, case in primary.items():
        expected = {"from_start", "prefix"}
        if key in eligible:
            expected.update(("full", "short", "history_short", "continue"))
            for arm in expected - {"from_start", "prefix"}:
                assert case[arm]["snapshot"] == case["prefix"]["snapshot"]
            extra = probes[key]
            for arm in ("full_instead", "short_plain"):
                assert extra[arm]["snapshot"] == case["prefix"]["snapshot"]
            if extra["late_prefix"]["eligible"]:
                for arm in ("late_full", "late_continue"):
                    assert extra[arm]["snapshot"] == extra["late_prefix"]["snapshot"]
            records.extend(extra.values())
        assert set(case) == expected
        records.extend(case.values())
    records.extend(oracle)
    columns = ["seed", "original", "goal", "arm", "text", "eligible", "landed", "success","reference",
               "steps", "extra_steps", "old_target_distance_m", "snapshot"]
    with (ROOT / "all_trials.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        writer.writerows(sorted(records, key=lambda r: (r["seed"], r["original"], r["arm"])))
    counts = Counter((row["arm"], row["original"], row.get("landed", str(row.get("eligible"))))
                     for row in records)
    for key in sorted(counts):
        print(*key, counts[key])
    example(primary[(0, "plate")], probes[(0, "plate")])


def example(case, probe):
    folder = ROOT / "paired"
    with np.load(folder / "snapshot_0_plate.npz") as data:
        snap = Image.fromarray(data["agentview"][::-1, ::-1])
    with np.load(ROOT / "probes/late_snapshot_0_plate.npz") as data:
        late_snap = Image.fromarray(data["agentview"][::-1, ::-1])
    sheet = Image.new("RGB", (938, 826), "#f5f5f2")
    draw = ImageDraw.Draw(sheet)
    font_dir = Path("C:/Windows/Fonts")
    def font(size, bold=False):
        return ImageFont.truetype(str(font_dir / ("msyhbd.ttc" if bold else "msyh.ttc")), size)
    draw.text((28, 16), "从盘子改送到炉面，纠正的说法和时机都影响结果", font=font(28, True), fill="#172533")
    draw.text((30, 62), "SmolVLA  ·  LIBERO-Goal  ·  布局 0  ·  前两行从同一状态出发，第三行晚 11 步给出指令",
              font=font(17), fill="#51606b")
    for x, label in zip((306, 513, 720), ("纠正时刻", "纠正后第 16 步", "回合终点")):
        draw.text((x, 110), label, font=font(19, True), fill="#273947")
    for n, arm in enumerate(("short", "full", "late_full")):
        row = case[arm] if n < 2 else probe[arm]
        y = 150 + 220 * n
        draw.text((30, y + 18), ("刚抓稳 · 简短纠正", "刚抓稳 · 完整指令", "接近盘子 · 完整指令")[n], font=font(22, True), fill="#172533")
        draw.text((30, y + 64), row["text"], font=font(17), fill="#273947")
        text = {"timeout":"超时", "plate":"放到盘子", "stove":"放到炉面"}[row["landed"]]
        draw.text((30, y + 108), f'{text}  ·  {row["steps"]} 步', font=font(18, True),
                  fill=("#8b572a" if row["landed"] == "timeout" else "#14634d"))
        source = folder if n < 2 else ROOT / "probes"
        with Image.open(source / f"0_plate_{arm}.jpg") as strip:
            frames = (snap if n < 2 else late_snap, strip.crop((144, 0, 288, 144)),
                      strip.crop((strip.width-144, 0, strip.width, 144)))
            for x, frame in zip((300, 507, 714), frames):
                sheet.paste(frame.resize((196, 196), Image.Resampling.LANCZOS), (x, y))
    sheet.save(ROOT / "paired_example.png")


if __name__ == "__main__":
    main()
