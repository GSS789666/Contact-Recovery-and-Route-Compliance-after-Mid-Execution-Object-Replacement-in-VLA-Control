# 运行环境与计数规则

实际软件版本见 [environment.json](environment.json)。Windows 原生运行，模型推理使用 NVIDIA RTX 5060 Laptop GPU，仿真使用 MuJoCo、robosuite 和 GLFW 离屏相机。工作站的包与模型保存在 `%LOCALAPPDATA%/vla-pilot`，实验代码和输出在本目录。

- 冻结策略为 [lerobot/smolvla_libero](https://huggingface.co/lerobot/smolvla_libero/tree/a24f1f380461b665158d52acd140152c79e8b36d)。权重 SHA-256 为 `9a9f6413e42c0f332fccbce9a0dc796af2790f82cf002f791cdbf7e01e1afca8`。词表及骨干配置采用 `HuggingFaceTB/SmolVLM2-500M-Video-Instruct` 的 `4cde9d208e19519c36917aa170fffc7e381aa0ad`，所有网络参数来自冻结策略权重。
- LIBERO 桌面场景使用原版网格、纹理、初始状态和目标谓词。此机的隔离环境中，robosuite 1.4.0 的 `macros.py` 设置 `FILE_LOGGING_LEVEL=None` 避免写入 Unix 路径，`MUJOCO_GPU_RENDERING=False` 避免强行选用 EGL，GLFW 负责建立 OpenGL 上下文。`utils/binding_utils.py` 的 Windows DLL 搜索位置改为已安装的 mujoco 包目录。`libero/libero/assets` 指向本地官方资产目录。
- 每个推理输入含两个 256×256 相机图像、末端位置与轴角、两个夹爪关节位置和英文指令。按 LeRobot 的 LIBERO 预处理旋转相机图像、使用检查点的状态和动作归一化统计量。默认每次生成 50 步动作，执行前 10 步后重新观测。
- 初始化后执行 10 步静置。抓碗后的位置至少比初始高度高 1.5 cm，同时符合仿真器抓握谓词，连续 3 步即形成纠正时刻。各分支重新执行相同前缀，核对物理状态与两幅相机图像的联合 SHA-256，重新设置相同的随机种子并清空动作缓存。分支主终点为任一目的地连续 3 步成立放置谓词且已解除抓握。超时单独计数。
- 从起点执行目标完整指令与执行中给出完整指令是两个不同对照。前者检查原子任务是否可做，后者检查从既有抓取状态切换目标的能力。继续原指令也重新推理，用于检查单纯中断动作缓冲的影响。

## 在原工作站复跑

在包含 `vla_pilot` 的工作区打开 PowerShell。下面使用新输出目录，保留已有数据。

```powershell
$pilotPython = "$env:LOCALAPPDATA/vla-pilot/venv/Scripts/python.exe"
& $pilotPython -u vla_pilot/run.py --seeds 0 1 2 3 --out vla_pilot/paired_repeat
& $pilotPython -u vla_pilot/followup.py --source vla_pilot/paired_repeat --out vla_pilot/probes_repeat --seeds 0 1 2 3
```

附加实验沿主实验“继续原指令”分支保存的动作向前回放。夹爪仍抓着碗、碗与原目标中心的水平距离首次进入 6 cm、且原目标放置谓词为假时，形成较晚快照。两个时刻对应不同物理状态。所有同一时刻内的语言对照都从一致的物理状态与图像开始；仿真控制频率为 20 Hz。主实验一次分支回放未通过联合摘要核验，程序在策略推理之前中止。续跑使用已保存的原始前缀及相同种子，已完成的回合保留，补做的分支须通过原摘要核验。CSV 一行对应一个条件和一个方向，前缀行只描述快照。

可达性对照使用模拟器中的碗位置和同一布局早期成功轨迹的终点坐标。控制器持碗抬高、水平移动、下降，再开爪。逐元素核对晚期快照的物理状态后才执行，同样在首次连续三步满足落点判据或达到 180 步时结束。该分支无需相机，产生的结果用于判断每个晚期物理状态是否有可行续轨迹。复核原始实验使用 `feasibility.py`（补齐原目录中缺少的可达性回合）和 `summarize.py`（校验记录、整理 CSV 与示例图）。
