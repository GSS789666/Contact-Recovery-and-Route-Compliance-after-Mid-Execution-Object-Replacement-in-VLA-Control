"""Fetch pinned public policy files, verifying the weight digest before use."""
import concurrent.futures
import hashlib
import os
from pathlib import Path
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

root = Path(os.environ.get("VLA_PILOT_HOME", Path(os.environ["LOCALAPPDATA"]) / "vla-pilot"))

def session():
    client = requests.Session()
    client.mount("https://", HTTPAdapter(max_retries=Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])))
    return client

def fetch(repo, folder, weights, rev):
    client = session()
    files = client.get(f"https://huggingface.co/api/models/{repo}/tree/{rev}", timeout=30).json()
    target = root / folder
    target.mkdir(parents=True, exist_ok=True)
    for item in files:
        name = item["path"]
        if item["type"] != "file" or name.startswith(".") or not name.endswith((".json", ".txt", ".safetensors")):
            continue
        if name == "model.safetensors" and not weights:
            continue
        file = target / name
        url = f"https://huggingface.co/{repo}/resolve/{rev}/{name}"
        if file.exists() and file.stat().st_size == item["size"]:
            if "lfs" not in item or hashlib.file_digest(file.open("rb"), "sha256").hexdigest() == item["lfs"]["oid"]:
                continue
        if item["size"] < 16_000_000:
            res = client.get(url, timeout=60)
            res.raise_for_status()
            file.write_bytes(res.content)
            continue
        chunk = 8 * 1024**2
        staging = target / "parts"
        staging.mkdir(exist_ok=True)
        def part(start):
            end = min(start + chunk, item["size"]) - 1
            fp = staging / str(start)
            if fp.exists() and fp.stat().st_size == end-start+1:
                return fp
            for attempt in range(5):
                try:
                    res = session().get(url + f"?part={start}", headers={"Range": f"bytes={start}-{end}"}, timeout=90)
                    if res.status_code != 206 or len(res.content) != end-start+1 or not res.headers.get("Content-Range","").startswith(f"bytes {start}-{end}/"):
                        raise ValueError(f"invalid range {start} {res.status_code}")
                    fp.write_bytes(res.content)
                    return fp
                except (requests.RequestException, ValueError):
                    if attempt == 4:
                        raise
        with concurrent.futures.ThreadPoolExecutor(10) as pool, (target/"assembled.tmp").open("wb") as out:
            for index, fp in enumerate(pool.map(part, range(0,item["size"],chunk))):
                out.write(fp.read_bytes())
                if index % 20 == 0:
                    print("Verified range", index, flush=True)
        with (target/"assembled.tmp").open("rb") as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == item["lfs"]["oid"]
        (target/"assembled.tmp").replace(file)
    (target/"revision.txt").write_text(rev)
    print(repo, rev, flush=True)

if __name__ == "__main__":
    fetch("HuggingFaceTB/SmolVLM2-500M-Video-Instruct","vlm",False,"4cde9d208e19519c36917aa170fffc7e381aa0ad")
    fetch("lerobot/smolvla_libero","policy",True,"a24f1f380461b665158d52acd140152c79e8b36d")
