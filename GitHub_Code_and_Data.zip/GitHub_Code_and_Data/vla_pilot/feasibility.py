"""Physically test whether a privileged position controller can reroute the held bowl."""
import json
from pathlib import Path

import numpy as np

from run import BOWL, LIB, TARGETS, at, held, record, reset_to_start
from libero.libero.envs.env_wrapper import ControlEnv

ROOT = Path(__file__).resolve().parent


def transport(env, obs, dest, goal):
    start = obs[BOWL + "_pos"].copy()
    clearance = max(start[2], dest[2]) + 0.10
    above_start = np.r_[start[:2], clearance]
    above_dest = np.r_[dest[:2], clearance]
    waypoints = [above_start, above_dest, dest + [0, 0, 0.012]]
    phase = 0
    stable = {k: 0 for k in TARGETS}
    trace = []
    for _ in range(180):
        pos = obs[BOWL + "_pos"]
        error = waypoints[min(phase, 2)] - pos
        if phase < 3 and np.linalg.norm(error) <= 0.014:
            phase += 1
        if phase < 3:
            delta = np.clip(18 * (waypoints[phase] - pos), -0.6, 0.6)
            action = np.r_[delta, 0, 0, 0, 1]
        else:
            action = np.array([0., 0., 0., 0., 0., 0., -1.])
        obs = env.step(action)[0]
        trace.append(np.r_[action, obs["robot0_eef_pos"], obs[BOWL + "_pos"]])
        for k in TARGETS:
            stable[k] = stable[k] + 1 if at(env, k) and not held(env) else 0
            if stable[k] >= 3:
                return {"landed": k, "success": k == goal, "steps": len(trace)}, trace
    return {"landed": "timeout", "success": False, "steps": len(trace)}, trace


def main():
    source = ROOT / "probes"
    target = ROOT / "oracle"
    target.mkdir(exist_ok=True)
    log = target / "trials.jsonl"
    completed = {(r["seed"],r["original"]) for r in map(json.loads,log.read_text().splitlines())} if log.exists() else set()
    primary = {(r["seed"],r["original"],r["arm"]): r for r in
               map(json.loads,(ROOT / "paired/trials.jsonl").read_text().splitlines())}
    scene = LIB / "bddl_files/libero_goal/put_the_bowl_on_the_plate.bddl"
    env = ControlEnv(bddl_file_name=str(scene), use_camera_obs=False, has_offscreen_renderer=False,
                     hard_reset=True, ignore_done=True)
    try:
        for row in map(json.loads,(source/"trials.jsonl").read_text().splitlines()):
            if row["arm"] != "late_prefix" or not row["eligible"]:
                continue
            seed, original, goal = row["seed"], row["original"], row["goal"]
            if (seed, original) in completed:
                continue
            reference = next((arm for arm in ("full", "from_start") if primary[seed,original,arm]["success"]), None)
            if reference is None:
                raise ValueError(f"No successful target reference for {seed} {original}")
            with np.load(ROOT / "paired" / f"{seed}_{original}_{reference}.npz") as ref:
                dest = ref["actions_eef_bowl"][-1, -3:].copy()
            with np.load(source / f"late_snapshot_{seed}_{original}.npz") as snap:
                obs = reset_to_start(env, snap["initial"], seed)
                for action in snap["prefix"]:
                    obs = env.step(action)[0]
                assert np.array_equal(env.sim.get_state().flatten(),snap["physics"])
            assert held(env) and not at(env, original)
            result, trace = transport(env, obs, dest, goal)
            np.savez_compressed(target / f"{seed}_{original}.npz", actions_eef_bowl=np.stack(trace))
            record(log, {"seed": seed, "original": original, "goal": goal, "arm":"oracle",
                         "snapshot":row["snapshot"],"reference":reference,**result})
    finally:
        env.close()


if __name__ == "__main__":
    main()
