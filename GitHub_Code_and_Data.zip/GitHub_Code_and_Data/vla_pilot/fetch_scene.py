"""Fetch the public LIBERO geometry and textures used by the tabletop pilot."""
import hashlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import requests

REV = "8f1084e3132a39270c3a13ebe37270a43ece2a01"
REPO = "Lifelong-Robot-Learning/LIBERO"
PREFIX = "libero/libero/assets/"
root = Path(sys.argv[1])
patterns = ("textures/", "articulated_objects/", "stable_scanned_objects/akita_black_bowl/",
            "stable_scanned_objects/plate/", "stable_hope_objects/cream_cheese/",
            "turbosquid_objects/wine_bottle/", "turbosquid_objects/wine_rack/",
            "turbosquid_objects/wooden_cabinet_base/", "scenes/libero_tabletop",
            "turbosquid_objects/wine_rack_stand/", "wall", "serving_region")
tree = requests.get(f"https://api.github.com/repos/{REPO}/git/trees/{REV}?recursive=1",timeout=30).json()["tree"]
def download(entry):
    name = entry["path"][len(PREFIX):]
    path = root / name
    if path.is_file() and path.stat().st_size == entry["size"]:
        return
    data = requests.get(f"https://raw.githubusercontent.com/{REPO}/{REV}/{entry['path']}",timeout=120)
    data.raise_for_status()
    blob = data.content
    if hashlib.sha1(f"blob {len(blob)}\0".encode()+blob).hexdigest()!=entry["sha"]:
        raise ValueError(name)
    path.parent.mkdir(exist_ok=True,parents=True)
    path.write_bytes(blob)
if __name__ == "__main__":
    selected=[e for e in tree if e["type"]=="blob" and e["path"].startswith(PREFIX)
              and e["path"][len(PREFIX):].startswith(patterns)]
    with ThreadPoolExecutor(12) as pool:
        list(pool.map(download,selected))
    print(f"Checked {len(selected)} scene files.")
