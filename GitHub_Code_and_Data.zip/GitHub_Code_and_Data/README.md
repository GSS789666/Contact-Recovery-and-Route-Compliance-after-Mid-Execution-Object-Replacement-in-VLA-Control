# Contact recovery and route compliance in LIBERO

Replication repository for the study by Shengshuo Gong and Oleg O. Varlamov on held-object replacement in vision–language–action control. It includes the protocols, simulator and analysis code, training and calibration data, fitted residuals, restored interruption states and trajectories behind 1,211 paired simulation episodes.

## Check the recorded results

Use Python 3.11 from the extracted repository root. The audit uses a temporary copy and leaves the distributed measurements intact.

```sh
python -m pip install numpy==1.26.4
python verify_results.py
```

[REPRODUCE.md](REPRODUCE.md) maps each outcome to its executable experiment, fixed layout ranges and run tags. [SETUP.md](SETUP.md) describes the separate GPU environment, pinned base checkpoint and LIBERO assets for native rollouts. See [THIRD_PARTY.md](THIRD_PARTY.md) for upstream materials.

| Group | Evaluation | Episodes |
| --- | --- | ---: |
| A | Kitchen contact constraints and persistent reduced gain | 429 |
| B | Kitchen action-box and sampler-placement ablations | 170 |
| C | Observed-motion compensation during transient slowdown | 270 |
| D | Few-shot adaptation to the basket scene | 192 |
| E | Physical route compliance with matched wording swaps | 150 |

The measurements apply to the specified simulator, layouts, edit templates and checkpoints. Use the supplied SHA-256 manifest to verify the released copy.
