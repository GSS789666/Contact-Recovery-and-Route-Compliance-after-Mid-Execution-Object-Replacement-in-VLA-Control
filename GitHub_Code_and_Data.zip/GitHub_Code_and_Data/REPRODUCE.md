# Replication guide

This guide maps the manuscript to the recorded experiments. Run commands from the extracted repository root. Use Python 3.11 and NumPy 1.26.4 for the CPU data audit. For native replay use the configured interpreter from [SETUP.md](SETUP.md), the recorded versions in [runtime-versions.tsv](runtime-versions.tsv), the pinned SmolVLA checkpoint and the complete LIBERO assets.

The kitchen uses `put_the_bowl_on_the_plate` from `libero_goal`. The basket uses `pick_up_the_cream_cheese_and_place_it_in_the_basket` from `libero_object`. Both BDDL and initial-state lookups use the respective suite directory.

## Audit the publication data on a CPU

```sh
python verify_results.py
```

The verifier checks the file manifest, then runs the primary and independent analyzers in a temporary directory and compares their reports with the distributed results. The checks cover run and state identities, design coverage, outcome counts, action traces, perturbation schedules, and layout-level uncertainty. The basket audits rescore first delivery and the approach from archived physical trace channels. The kitchen scorer's first stable object–destination pair is archived in each trial record. Kitchen audits separately verify snapshot identities, paired coverage, trace lengths, grasp and lift events, and applied gain. No GPU or policy weights download is needed for this audit.

To regenerate the five manuscript tables and the two result figures, install Matplotlib and run `python information_vla/integrated/artifacts.py`. Outputs are written to `information_vla/integrated/paper/`. The separate LaTeX source archive contains these outputs and the illustrative demonstration montage.

## Map groups to scripts and archived data

The file `trials.jsonl` in each run directory records the layout, intervention stage, command, method, snapshot digest and measured outcome. Same-key `.npz` files contain the numerical traces. Each study directory also contains the protocol, eligible snapshots, calibration or training metadata, aggregate JSON and per-episode CSV. A and B share `information_vla/iteration2`. C, D and E share `information_vla/iteration3`.

| Group | Layout range and design | Entry point and official tags |
| --- | --- | --- |
| A | Kitchen 14–25, 39 of 48 candidate interruptions, 11 eligible layouts, 429 episodes | `run_study.py` → `canonicaltest ordinarytest closure timing means onlyservo witness slowevent slowclock` |
| B | Kitchen 26–35, 34 of 40 interruptions, 10 layouts, 170 episodes | `run_flow.py` → `flowbase flowshort flowlate flowinside`. `run_center.py` → `flowcenter`. |
| C | Kitchen 36–49, 45 of 56 interruptions, 14 layouts, 270 episodes | `timing.py` → `timingnominal timingtransient` |
| D | Basket 8–19, 24 interruptions × two objects × four methods, 192 episodes | `basket_evaluate.py` → `transfervla transfergeom` |
| E | Basket 20–35, 15 qualified grasp states × two sides × five methods, 150 episodes | `basket_evaluate.py` → `routecontrols routeoutput routeinside routeswap` |

All policies start from verified common action prefixes. The evaluated layout is the pairing unit for uncertainty. Each group gives equal weight to its qualifying layouts. The primary analysis uses 100,000 empirical layout-bootstrap replicates. The independent checks also calculate the percentile interval from exact resampling distributions. The arrays and count tables are retained for every arm, including the equal-success within-flow comparison.

## Run fresh native episodes

Keep the released copy intact. In a separate extracted working copy, direct the workers to unused tags for quick checks. The following PowerShell examples use the first eligible layout in each group and create fresh logs.

```powershell
$k = 'information_vla/iteration2'
$b = 'information_vla/iteration3'
python "$k/run_study.py" --layouts 14 --methods event canonical --tag check_a
python "$k/run_flow.py" --layouts 26 --methods late inside --tag check_b
python "$b/timing.py" --layouts 36 --methods compensated --conditions transient --tag check_c
python "$b/basket_evaluate.py" --layouts 8 --study transfer --methods late --residual --tag check_d
python "$b/basket_evaluate.py" --layouts 20 --study routes --targets butter --stages grasp --methods late swapped --residual --tag check_e
```

For all arms, the commands in [the kitchen protocol](information_vla/iteration2/REPRODUCE_revision.md) specify A and B, and the `$jobs` array in [the follow-up runner](information_vla/iteration3/finish.ps1) specifies C–E. For each listed follow-up job, run `python information_vla/iteration3/<script> --tag <tag> <args>`. The array lists the expected row count per tag. It can be used without the original Windows job scheduler.

For complete reruns, use a fresh extracted copy separate from the quick checks. Move the original formal tag directories outside `runs/` in that copy, then use the exact official tags from the table. Also keep any quick-check outputs or other reruns outside `runs/` when invoking the independent timing analysis. It searches all timing logs in this directory and rejects duplicate intervention keys. For the kitchen example commands in the original protocol, take the tags in each group's listed order below. The geometry witness also needs its historical driver.

| Kitchen command sequence | Replace the example tags with |
| --- | --- |
| Canonical, ordinary, event, clock, mean, standalone, teacher, slow event, slow clock | `canonicaltest ordinarytest closure timing means onlyservo witness slowevent slowclock` |
| Canonical ten, short, late, inside | `flowbase flowshort flowlate flowinside` |

Use the four files in `information_vla/iteration2/dev1_sources.zip` for the privileged witness in its own extracted working copy. Place those files at `information_vla/iteration2/` within that copy and run the teacher command. Copy the new `runs/witness/` output directory to the fresh replay used for the other arms. The normal analysis recognizes the historical driver through its recorded source hashes. Run `run_center.py` with the fixed `flowcenter` tag in the normal replay copy. On the replay copy, run the six analysis commands in `verify_results.py` directly. The manifest verifier is for the distributed records, so run it on the untouched release copy.

The archived eligibility and prefixes are the fixed test inputs. To collect new prefixes, use a separate copy with empty relevant snapshot directories. Kitchen A/B use `prefixes.py` for layouts 14–35, C uses `collect_timing.py` for 36–49, and D/E use `basket_scene.py` for 8–35. Record any changed eligibility or snapshot digests as a new experiment. Platform differences may change rendered state hashes or control trajectories.

## Refit controllers and audit settings

- **Kitchen residuals.** [The original training guide](information_vla/REPRODUCE.md) documents how to rebuild demonstration features and fit the ordinary and complete-goal heads. Formal trials load `weights/33_ordinary.pt` and `weights/33_canonical.pt`. The frozen action-expert input has 720 features. The residual fits use seed 33, AdamW at 0.001, batches of 64, norm clip 2, up to 50 epochs, and minimum development velocity loss. Kitchen layouts 0–5 supply 61 training demonstrations. Layouts 6–7 supply 21 development demonstrations. Only the 17 training substitutions contribute to `geometry.npz` and `event_field.npz`. Archived `events/` contain the fitted quantities' source labels.
- **Direct recovery.** `contact_policy.py` implements the 12 ordered phases and coordinate conventions. It uses 23/19 translation gains, clips the proportional center to ±0.75, and uses precision and transit half-widths 0.035/0.10. Rotation half-width is 0.012 and the grip command is fixed by phase. The kitchen stop thresholds are 0.015 and 0.009 m. Opening uses a seven-control dwell and the fitted aperture threshold. Closing uses nine controls with at most one retry. The scheduled clock takes phase-wise medians of the three nearest kitchen starts, with a 0.12 m penalty for a different original destination.
- **Five-control blocks.** `fit_event_field.py` estimates phase gains by minimum translational MAE on 8.0–35.5 in 0.5 increments. It uses the 60th percentile absolute residual per dimension clipped to 0.025–0.15 and adjacent-command least-squares decay clipped to 0.82–1. The projected prefix has five actions and the sampler performs ten updates of size 0.1. Within-flow projection maps the predicted clean endpoint into the box, then maps that endpoint back into velocity space for the Euler update. Output-only projection clips the endpoint once. The queue resets on phase changes.
- **Timing.** `timing.py` uses the median positive end-effector displacement projected onto unscaled commands with norm at least 0.22 as its reference. It clips each measured/reference ratio to 0.15–1.20 and takes the median of the last five, starting with five ones. The compensated clock increments by one for gripper dwell and by the estimated ratio otherwise. The fixed clock increments by one per control. Persistent gain in group A is 0.65. The C perturbation uses gain 0.45 at zero-based controls 45–84 inclusive, and 1.0 elsewhere.
- **Basket calibration and fitting.** [The follow-up protocol](information_vla/iteration3/README.md) gives the commands for fitting the image geometry, residual and behavior clone. Layouts 0–5 supply the calibration and 12 unrouted plus 12 routed replacement demonstrations. Layouts 6–7 are for development. The residual uses seed 1335, AdamW at 0.001, batch 32, norm clip 2 and 35 epochs. The behavior clone uses seed 137, AdamW at 0.002, batch 128 and 40 epochs. It learns masked five-control MSE plus 0.2 times the route classification loss on labeled blocks. The release heights from the basket body origin are 0.190 m for butter and 0.204 m for tomato sauce. `basket_control.py` defines all per-phase gains, arrival thresholds, dwell and retry logic.
- **Route semantics.** `basket_evaluate.py` and `native_guidance.py` implement scoring and prompt interventions. Candidate approach waypoints differ by 104 mm along the lateral axis. The reference is 93 mm above the pickup target. The scorer requires a lateral center passage within 20 mm after release of the old item, then two successive controls in the requested 32–78 mm gate before replacement grasp. Both gates require less than 25 mm of deviation on the other axes. Positive world-y offset scores as left and negative as right. The digest confirms the same choice observation and boxes under opposite wording. Route success also requires the correct first delivery.
- **Budget and seeds.** Kitchen stops at 180 controls and uses continuation seed `3033 + layout_id`. Basket stops at 240 and uses `5047 + layout_id`. Both stop early on the first stable registered delivery. Route success adds the independently scored approach. See the kitchen [event schema](information_vla/iteration2/event_schema.md) and basket [data contract](information_vla/iteration3/data_contract.md) for trace fields and coordinate conventions.
